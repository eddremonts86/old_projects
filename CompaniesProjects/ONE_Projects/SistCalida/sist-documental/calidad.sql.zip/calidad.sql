-- phpMyAdmin SQL Dump
-- version 3.3.2deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 27-02-2012 a las 13:28:37
-- Versión del servidor: 5.1.41
-- Versión de PHP: 5.3.2-1ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `calidad`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_banner`
--

CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `cid` int(11) NOT NULL DEFAULT '0',
  `type` varchar(30) NOT NULL DEFAULT 'banner',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `imptotal` int(11) NOT NULL DEFAULT '0',
  `impmade` int(11) NOT NULL DEFAULT '0',
  `clicks` int(11) NOT NULL DEFAULT '0',
  `imageurl` varchar(100) NOT NULL DEFAULT '',
  `clickurl` varchar(200) NOT NULL DEFAULT '',
  `date` datetime DEFAULT NULL,
  `showBanner` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Volcar la base de datos para la tabla `jos_banner`
--

INSERT INTO `jos_banner` (`bid`, `cid`, `type`, `name`, `alias`, `imptotal`, `impmade`, `clicks`, `imageurl`, `clickurl`, `date`, `showBanner`, `checked_out`, `checked_out_time`, `editor`, `custombannercode`, `catid`, `description`, `sticky`, `ordering`, `publish_up`, `publish_down`, `tags`, `params`) VALUES
(1, 1, '', 'OSM 1', 'osm-1', 0, 53840, 357, 'logoONEI.png', 'http://192.168.152.3/oneprinternal/', '2011-08-25 14:25:00', 1, 0, '0000-00-00 00:00:00', '', '', 14, '', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', ''),
(2, 1, '', 'OSM 2', 'osm-2', 0, 52082, 339, 'logoONEI.png', 'http://www.opensourcematters.org', '2011-08-25 14:25:43', 0, 0, '0000-00-00 00:00:00', '', '', 14, '', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_bannerclient`
--

CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `contact` varchar(255) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out_time` time DEFAULT NULL,
  `editor` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `jos_bannerclient`
--

INSERT INTO `jos_bannerclient` (`cid`, `name`, `contact`, `email`, `extrainfo`, `checked_out`, `checked_out_time`, `editor`) VALUES
(1, 'Open Source Matters', 'Administrator', 'admin@opensourcematters.org', '', 0, '00:00:00', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_bannertrack`
--

CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL DEFAULT '0000-00-00',
  `track_type` int(10) unsigned NOT NULL DEFAULT '0',
  `banner_id` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_bannertrack`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_categories`
--

CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` varchar(255) NOT NULL DEFAULT '',
  `section` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `editor` varchar(50) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Volcar la base de datos para la tabla `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`) VALUES
(1, 0, 'Latest', 'Latest News', 'latest', 'taking_notes.jpg', '1', 'left', 'The latest news from the Joomla! Team', 1, 0, '0000-00-00 00:00:00', '', 0, 0, 1, ''),
(2, 0, 'Joomla!', 'Joomla!', 'joomla', 'clock.jpg', 'com_weblinks', 'left', 'A selection of links that are all related to the Joomla! Project.', 1, 0, '0000-00-00 00:00:00', '', 0, 0, 0, ''),
(3, 0, 'Newsflash', 'Newsflash', 'newsflash', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 1, 0, 0, ''),
(4, 0, 'Joomla!', 'Joomla!', 'joomla', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 2, 0, 0, ''),
(5, 0, 'Business: general', 'Business: general', 'business-general', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 1, 0, 0, ''),
(7, 0, 'Examples', 'Example FAQs', 'examples', 'key.jpg', '3', 'left', 'Here you will find an example set of FAQs.', 1, 0, '0000-00-00 00:00:00', '', 0, 0, 2, ''),
(9, 0, 'Finance', 'Finance', 'finance', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 5, 0, 0, ''),
(10, 0, 'Linux', 'Linux', 'linux', '', 'com_newsfeeds', 'left', '<br />\r\n', 1, 0, '0000-00-00 00:00:00', '', 6, 0, 0, ''),
(11, 0, 'Internet', 'Internet', 'internet', '', 'com_newsfeeds', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 7, 0, 0, ''),
(12, 0, 'Contacts', 'Contacts', 'contacts', '', 'com_contact_details', 'left', 'Contact Details for this website', 1, 0, '0000-00-00 00:00:00', '', 0, 0, 0, ''),
(13, 0, 'Top', 'Top', 'top', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', '', 2, 0, 0, 'imagefolders=*2*'),
(14, 0, 'mio', '', 'mo', 'articles.jpg', 'com_banner', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_components`
--

CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `link` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) unsigned NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `admin_menu_link` varchar(255) NOT NULL DEFAULT '',
  `admin_menu_alt` varchar(255) NOT NULL DEFAULT '',
  `option` varchar(50) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `admin_menu_img` varchar(255) NOT NULL DEFAULT '',
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- Volcar la base de datos para la tabla `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, 'show_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\nallowed_media_usergroup=3\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html\nenable_flash=0\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'link_titles=0\nshow_author=1\nshow_create_date=\nshow_modify_date=\nshow_email_icon=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_hits=1\nshow_icons=1\nshow_readmore=1\nshow_noauth=0\nshow_item_navigation=1\nshow_vote=0\nshow_title=1\nshow_intro=1\nshow_noauth=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, 'site=es-ES\nadministrator=es-ES\n\n', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=0\nnew_usertype=Registered\nuseractivation=0\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1),
(34, 'Community Builder', 'option=com_comprofiler', 0, 0, 'option=com_comprofiler', 'Community Builder', 'com_comprofiler', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(35, 'User Management', '', 0, 34, 'option=com_comprofiler&task=showusers', 'User Management', 'com_comprofiler', 0, 'js/ThemeOffice/users.png', 0, '', 1),
(36, 'Tab Management', '', 0, 34, 'option=com_comprofiler&task=showTab', 'Tab Management', 'com_comprofiler', 1, 'js/ThemeOffice/content.png', 0, '', 1),
(37, 'Field Management', '', 0, 34, 'option=com_comprofiler&task=showField', 'Field Management', 'com_comprofiler', 2, 'js/ThemeOffice/content.png', 0, '', 1),
(38, 'List Management', '', 0, 34, 'option=com_comprofiler&task=showLists', 'List Management', 'com_comprofiler', 3, 'js/ThemeOffice/content.png', 0, '', 1),
(39, 'Plugin Management', '', 0, 34, 'option=com_comprofiler&task=showPlugins', 'Plugin Management', 'com_comprofiler', 4, 'js/ThemeOffice/install.png', 0, '', 1),
(40, 'Tools', '', 0, 34, 'option=com_comprofiler&task=tools', 'Tools', 'com_comprofiler', 5, 'js/ThemeOffice/component.png', 0, '', 1),
(41, 'Configuration', '', 0, 34, 'option=com_comprofiler&task=showconfig', 'Configuration', 'com_comprofiler', 6, 'js/ThemeOffice/config.png', 0, '', 1),
(42, 'eXtplorer', 'option=com_extplorer', 0, 0, 'option=com_extplorer', 'eXtplorer', 'com_extplorer', 0, '../administrator/components/com_extplorer/images/joomla_x_icon.png', 0, '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler` (
  `id` int(11) NOT NULL DEFAULT '0',
  `user_id` int(11) NOT NULL DEFAULT '0',
  `firstname` varchar(100) DEFAULT NULL,
  `middlename` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  `message_last_sent` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `message_number_sent` int(11) NOT NULL DEFAULT '0',
  `avatar` varchar(255) DEFAULT NULL,
  `avatarapproved` tinyint(4) DEFAULT '1',
  `approved` tinyint(4) NOT NULL DEFAULT '1',
  `confirmed` tinyint(4) NOT NULL DEFAULT '1',
  `lastupdatedate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `registeripaddr` varchar(50) NOT NULL DEFAULT '',
  `cbactivation` varchar(50) NOT NULL DEFAULT '',
  `banned` tinyint(4) NOT NULL DEFAULT '0',
  `banneddate` datetime DEFAULT NULL,
  `unbanneddate` datetime DEFAULT NULL,
  `bannedby` int(11) DEFAULT NULL,
  `unbannedby` int(11) DEFAULT NULL,
  `bannedreason` mediumtext,
  `acceptedterms` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `apprconfbanid` (`approved`,`confirmed`,`banned`,`id`),
  KEY `avatappr_apr_conf_ban_avatar` (`avatarapproved`,`approved`,`confirmed`,`banned`,`avatar`),
  KEY `lastupdatedate` (`lastupdatedate`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_comprofiler`
--

INSERT INTO `jos_comprofiler` (`id`, `user_id`, `firstname`, `middlename`, `lastname`, `hits`, `message_last_sent`, `message_number_sent`, `avatar`, `avatarapproved`, `approved`, `confirmed`, `lastupdatedate`, `registeripaddr`, `cbactivation`, `banned`, `banneddate`, `unbanneddate`, `bannedby`, `unbannedby`, `bannedreason`, `acceptedterms`) VALUES
(62, 62, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, 'gallery/kick.gif', 1, 1, 1, '2011-12-05 13:53:49', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(71, 71, '', '', '', 3, '0000-00-00 00:00:00', 0, 'gallery/frog.gif', 1, 1, 1, '2008-07-16 14:33:40', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(72, 72, NULL, NULL, NULL, 2, '0000-00-00 00:00:00', 0, '72_487e4db3908ab.jpg', 0, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(73, 73, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, 'gallery/guitar.gif', 1, 1, 1, '2008-07-16 14:37:50', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(74, 74, NULL, NULL, NULL, 1, '0000-00-00 00:00:00', 0, NULL, 1, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(75, 75, NULL, NULL, NULL, 2, '0000-00-00 00:00:00', 0, 'gallery/kick.gif', 1, 1, 1, '2008-07-16 14:40:12', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(76, 76, NULL, NULL, NULL, 2, '0000-00-00 00:00:00', 0, '76_487e4edfc2ec4.jpg', 0, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(77, 77, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, '77_487e4f207553b.jpg', 0, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(78, 78, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, '78_487e4f5d8bb7c.jpg', 0, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(79, 79, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, '79_487e4fd2a5d27.jpg', 0, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(80, 80, NULL, NULL, NULL, 0, '0000-00-00 00:00:00', 0, NULL, 1, 1, 1, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0),
(81, 81, '', '', '', 0, '0000-00-00 00:00:00', 0, NULL, 1, 0, 0, '0000-00-00 00:00:00', '', '', 0, NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_fields`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_fields` (
  `fieldid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '',
  `table` varchar(50) NOT NULL DEFAULT '#__comprofiler',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext NOT NULL,
  `type` varchar(50) NOT NULL DEFAULT '',
  `maxlength` int(11) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `required` tinyint(4) DEFAULT '0',
  `tabid` int(11) DEFAULT NULL,
  `ordering` int(11) DEFAULT NULL,
  `cols` int(11) DEFAULT NULL,
  `rows` int(11) DEFAULT NULL,
  `value` varchar(50) DEFAULT NULL,
  `default` mediumtext,
  `published` tinyint(1) NOT NULL DEFAULT '1',
  `registration` tinyint(1) NOT NULL DEFAULT '0',
  `profile` tinyint(1) NOT NULL DEFAULT '1',
  `readonly` tinyint(1) NOT NULL DEFAULT '0',
  `calculated` tinyint(1) NOT NULL DEFAULT '0',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  `pluginid` int(11) DEFAULT NULL,
  `params` mediumtext,
  PRIMARY KEY (`fieldid`),
  KEY `tabid_pub_prof_order` (`tabid`,`published`,`profile`,`ordering`),
  KEY `readonly_published_tabid` (`readonly`,`published`,`tabid`),
  KEY `registration_published_order` (`registration`,`published`,`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_fields`
--

INSERT INTO `jos_comprofiler_fields` (`fieldid`, `name`, `table`, `title`, `description`, `type`, `maxlength`, `size`, `required`, `tabid`, `ordering`, `cols`, `rows`, `value`, `default`, `published`, `registration`, `profile`, `readonly`, `calculated`, `sys`, `pluginid`, `params`) VALUES
(41, 'name', '#__users', '_UE_NAME', '', 'predefined', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(26, 'NA', '#__comprofiler', '_UE_ONLINESTATUS', '', 'status', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(27, 'lastvisitDate', '#__users', '_UE_LASTONLINE', '', 'date', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(28, 'registerDate', '#__users', '_UE_MEMBERSINCE', '', 'date', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(29, 'avatar', '#__comprofiler', '_UE_IMAGE', '', 'image', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(42, 'username', '#__users', '_UE_UNAME', '', 'predefined', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(45, 'NA', '#__comprofiler', '_UE_FORMATNAME', '', 'formatname', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(46, 'firstname', '#__comprofiler', '_UE_YOUR_FNAME', '', 'predefined', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(47, 'middlename', '#__comprofiler', '_UE_YOUR_MNAME', '', 'predefined', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(48, 'lastname', '#__comprofiler', '_UE_YOUR_LNAME', '', 'predefined', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(49, 'lastupdatedate', '#__comprofiler', '_UE_LASTUPDATEDON', '', 'date', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL),
(50, 'email', '#__users', '_UE_EMAIL', '', 'primaryemailaddress', NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, 0, 1, 0, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_field_values`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_field_values` (
  `fieldvalueid` int(11) NOT NULL AUTO_INCREMENT,
  `fieldid` int(11) NOT NULL DEFAULT '0',
  `fieldtitle` varchar(255) NOT NULL DEFAULT '',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`fieldvalueid`),
  KEY `fieldid_ordering` (`fieldid`,`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_field_values`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_lists`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_lists` (
  `listid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` mediumtext,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `default` tinyint(1) NOT NULL DEFAULT '0',
  `usergroupids` varchar(255) DEFAULT NULL,
  `useraccessgroupid` int(9) NOT NULL DEFAULT '18',
  `sortfields` varchar(255) DEFAULT NULL,
  `filterfields` varchar(255) DEFAULT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `col1title` varchar(255) DEFAULT NULL,
  `col1enabled` tinyint(1) NOT NULL DEFAULT '0',
  `col1fields` mediumtext,
  `col2title` varchar(255) DEFAULT NULL,
  `col2enabled` tinyint(1) NOT NULL DEFAULT '0',
  `col1captions` tinyint(1) NOT NULL DEFAULT '0',
  `col2fields` mediumtext,
  `col2captions` tinyint(1) NOT NULL DEFAULT '0',
  `col3title` varchar(255) DEFAULT NULL,
  `col3enabled` tinyint(1) NOT NULL DEFAULT '0',
  `col3fields` mediumtext,
  `col3captions` tinyint(1) NOT NULL DEFAULT '0',
  `col4title` varchar(255) DEFAULT NULL,
  `col4enabled` tinyint(1) NOT NULL DEFAULT '0',
  `col4fields` mediumtext,
  `col4captions` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`listid`),
  KEY `pub_ordering` (`published`,`ordering`),
  KEY `default_published` (`default`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_lists`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_members`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_members` (
  `referenceid` int(11) NOT NULL DEFAULT '0',
  `memberid` int(11) NOT NULL DEFAULT '0',
  `accepted` tinyint(1) NOT NULL DEFAULT '1',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `membersince` date NOT NULL DEFAULT '0000-00-00',
  `reason` mediumtext,
  `description` varchar(255) DEFAULT NULL,
  `type` mediumtext,
  PRIMARY KEY (`referenceid`,`memberid`),
  KEY `pamr` (`pending`,`accepted`,`memberid`,`referenceid`),
  KEY `aprm` (`accepted`,`pending`,`referenceid`,`memberid`),
  KEY `membrefid` (`memberid`,`referenceid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_members`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_plugin`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `type` varchar(100) DEFAULT '',
  `folder` varchar(100) DEFAULT '',
  `backend_menu` varchar(255) NOT NULL DEFAULT '',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`),
  KEY `type_pub_order` (`type`,`published`,`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=500 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_plugin`
--

INSERT INTO `jos_comprofiler_plugin` (`id`, `name`, `element`, `type`, `folder`, `backend_menu`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'CB Core', 'cb.core', 'user', 'plug_cbcore', '', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'CB Connections', 'cb.connections', 'user', 'plug_cbconnections', '', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(3, 'Content Author', 'cb.authortab', 'user', 'plug_cbmamboauthortab', '', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Simpleboard Forum', 'cb.simpleboardtab', 'user', 'plug_cbsimpleboardtab', '', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'Mamblog Blog', 'cb.mamblogtab', 'user', 'plug_cbmamblogtab', '', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(6, 'YaNC Newsletters', 'yanc', 'user', 'plug_yancintegration', '', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(7, 'Default', 'default', 'templates', 'default', '', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(8, 'WinClassic', 'winclassic', 'templates', 'winclassic', '', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(9, 'WebFX', 'webfx', 'templates', 'webfx', '', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(10, 'OSX', 'osx', 'templates', 'osx', '', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(11, 'Luna', 'luna', 'templates', 'luna', '', 0, 5, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(12, 'Dark', 'dark', 'templates', 'dark', '', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(13, 'Default language (English)', 'default_language', 'language', 'default_language', '', 0, -1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'CB Menu', 'cb.menu', 'user', 'plug_cbmenu', '', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(15, 'PMS MyPMS and Pro', 'pms.mypmspro', 'user', 'plug_pms_mypmspro', '', 0, 8, 0, 1, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_tabs`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_tabs` (
  `tabid` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL DEFAULT '',
  `description` text,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `ordering_register` int(11) NOT NULL DEFAULT '10',
  `width` varchar(10) NOT NULL DEFAULT '.5',
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `pluginclass` varchar(255) DEFAULT NULL,
  `pluginid` int(11) DEFAULT NULL,
  `fields` tinyint(1) NOT NULL DEFAULT '1',
  `params` mediumtext,
  `sys` tinyint(4) NOT NULL DEFAULT '0',
  `displaytype` varchar(255) NOT NULL DEFAULT '',
  `position` varchar(255) NOT NULL DEFAULT '',
  `useraccessgroupid` int(9) NOT NULL DEFAULT '-2',
  PRIMARY KEY (`tabid`),
  KEY `enabled_position_ordering` (`enabled`,`position`,`ordering`),
  KEY `orderreg_enabled_pos_order` (`enabled`,`ordering_register`,`position`,`ordering`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_tabs`
--

INSERT INTO `jos_comprofiler_tabs` (`tabid`, `title`, `description`, `ordering`, `ordering_register`, `width`, `enabled`, `pluginclass`, `pluginid`, `fields`, `params`, `sys`, `displaytype`, `position`, `useraccessgroupid`) VALUES
(11, '_UE_CONTACT_INFO_HEADER', '', -4, 10, '1', 1, 'getContactTab', 1, 1, NULL, 2, 'tab', 'cb_tabmain', -2),
(12, '_UE_AUTHORTAB', '', -3, 10, '1', 0, 'getAuthorTab', 3, 0, NULL, 1, 'tab', 'cb_tabmain', -2),
(13, '_UE_FORUMTAB', '', -2, 10, '1', 0, 'getForumTab', 4, 0, NULL, 1, 'tab', 'cb_tabmain', -2),
(14, '_UE_BLOGTAB', '', -1, 10, '1', 0, 'getBlogTab', 5, 0, NULL, 1, 'tab', 'cb_tabmain', -2),
(15, '_UE_CONNECTION', '', 99, 10, '1', 0, 'getConnectionTab', 2, 0, NULL, 1, 'tab', 'cb_tabmain', -2),
(16, '_UE_NEWSLETTER_HEADER', '_UE_NEWSLETTER_INTRODCUTION', 99, 10, '1', 0, 'getNewslettersTab', 6, 0, NULL, 1, 'tab', 'cb_tabmain', -2),
(17, '_UE_MENU', '', -10, 10, '1', 1, 'getMenuTab', 14, 0, NULL, 1, 'html', 'cb_head', -2),
(18, '_UE_CONNECTIONPATHS', '', -9, 10, '1', 1, 'getConnectionPathsTab', 2, 0, NULL, 1, 'html', 'cb_head', -2),
(19, '_UE_PROFILE_PAGE_TITLE', '', -8, 10, '1', 1, 'getPageTitleTab', 1, 0, NULL, 1, 'html', 'cb_head', -2),
(20, '_UE_PORTRAIT', '', -7, 10, '1', 1, 'getPortraitTab', 1, 0, NULL, 1, 'html', 'cb_middle', -2),
(21, '_UE_USER_STATUS', '', -6, 10, '.5', 1, 'getStatusTab', 14, 0, NULL, 1, 'html', 'cb_right', -2),
(22, '_UE_PMSTAB', '', -5, 10, '.5', 0, 'getmypmsproTab', 15, 0, NULL, 1, 'html', 'cb_right', -2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_userreports`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_userreports` (
  `reportid` int(11) NOT NULL AUTO_INCREMENT,
  `reporteduser` int(11) NOT NULL DEFAULT '0',
  `reportedbyuser` int(11) NOT NULL DEFAULT '0',
  `reportedondate` date NOT NULL DEFAULT '0000-00-00',
  `reportexplaination` text NOT NULL,
  `reportedstatus` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`reportid`),
  KEY `status_user_date` (`reportedstatus`,`reporteduser`,`reportedondate`),
  KEY `reportedbyuser_ondate` (`reportedbyuser`,`reportedondate`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_userreports`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_comprofiler_views`
--

CREATE TABLE IF NOT EXISTS `jos_comprofiler_views` (
  `viewer_id` int(11) NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  `lastview` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `viewscount` int(11) NOT NULL DEFAULT '0',
  `vote` tinyint(3) DEFAULT NULL,
  `lastvote` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`viewer_id`,`profile_id`,`lastip`),
  KEY `lastview` (`lastview`),
  KEY `profile_id_lastview` (`profile_id`,`lastview`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_comprofiler_views`
--

INSERT INTO `jos_comprofiler_views` (`viewer_id`, `profile_id`, `lastip`, `lastview`, `viewscount`, `vote`, `lastvote`) VALUES
(71, 72, '70.110.225.242', '2008-07-16 14:32:36', 1, NULL, '0000-00-00 00:00:00'),
(72, 71, '70.110.225.242', '2008-07-16 14:35:20', 1, NULL, '0000-00-00 00:00:00'),
(73, 72, '70.110.225.242', '2008-07-16 14:37:20', 1, NULL, '0000-00-00 00:00:00'),
(75, 71, '70.110.225.242', '2008-07-16 14:39:06', 1, NULL, '0000-00-00 00:00:00'),
(75, 74, '70.110.225.242', '2008-07-16 14:39:12', 1, NULL, '0000-00-00 00:00:00'),
(76, 75, '70.110.225.242', '2008-07-16 14:40:57', 1, NULL, '0000-00-00 00:00:00'),
(77, 76, '70.110.225.242', '2008-07-16 14:42:01', 1, NULL, '0000-00-00 00:00:00'),
(78, 76, '70.110.225.242', '2008-07-16 14:43:01', 1, NULL, '0000-00-00 00:00:00'),
(79, 71, '70.110.225.242', '2008-07-16 14:44:56', 1, NULL, '0000-00-00 00:00:00'),
(62, 75, '127.0.0.1', '2011-08-25 20:40:03', 1, NULL, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_contact_details`
--

CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `con_position` varchar(255) DEFAULT NULL,
  `address` text,
  `suburb` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `postcode` varchar(100) DEFAULT NULL,
  `telephone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `misc` mediumtext,
  `image` varchar(255) DEFAULT NULL,
  `imagepos` varchar(20) DEFAULT NULL,
  `email_to` varchar(255) DEFAULT NULL,
  `default_con` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `published` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL DEFAULT '0',
  `catid` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `webpage` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `jos_contact_details`
--

INSERT INTO `jos_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`) VALUES
(1, 'Name', 'name', 'Position', 'Street', 'Suburb', 'State', 'Country', 'Zip Code', 'Telephone', 'Fax', 'Miscellanous info', 'asterisk.png', 'top', 'email@email.com', 1, 1, 0, '0000-00-00 00:00:00', 1, '', 0, 12, 0, '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_content`
--

CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `title_alias` varchar(255) NOT NULL DEFAULT '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL DEFAULT '0',
  `sectionid` int(11) unsigned NOT NULL DEFAULT '0',
  `mask` int(11) unsigned NOT NULL DEFAULT '0',
  `catid` int(11) unsigned NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL DEFAULT '0',
  `created_by_alias` varchar(255) NOT NULL DEFAULT '',
  `modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL DEFAULT '1',
  `parentid` int(11) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0',
  `metadata` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=50 ;

--
-- Volcar la base de datos para la tabla `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(17, 'Installing Commportal', 'installing-commportal', 'Installing Commportal', '<br /><p><font size="4"><b>Joomla 1.0</b></font><br /></p><ol><li class="li_number1">Download the installation package from our download section.</li><li class="li_number2">Once the download is complete go to the backend of Joomla.</li><li class="li_number3">Navigate through your menu system to Installers/Templates - Site</li><li class="li_number4">Once at the installation screen click the browse button and navigate to where you downloaded the template file.</li><li class="li_number5">Once you have the file selected click &#39;Upload File and Install&#39;</li></ul><br /><div style="text-align: center"><img src="http://www.shape5.com/demo/bliss/images/template_install.gif" border="0" alt=" " width="400" height="69" /></div><ul class="numbers"><br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The template is now installed, now let&#39;s set it as the default template:<br /><br /><li class="li_number6">Navigate through your menu system to Site/Template Manager/SiteTemplates.</li><li class="li_number7">Find the radio button next to the newly installed template.</li><li class="li_number8">Click on the Default button at the top right of the screen and you&#39;re done!</li></ol><ul class="bullet_list"><ul class="bullet_list"><br />&nbsp;&nbsp;<div style="text-align: center"><img src="http://www.shape5.com/demo/bliss/images/default_button.gif" alt=" " width="154" height="108" /></div>\r\n  </ul>\r\n  <p><font size="4"><b>Joomla 1.5</b></font><br /></p><ul class="numbers"><li class="li_number1">Download the installation package from our download section.</li><li class="li_number2">Once the download is complete go to the backend of Joomla.</li><li class="li_number3">\r\n    Navigate through your menu system to Extensions/Install Uninstall.</li>\r\n    \r\n    <li class="li_number4">Once at the installation screen click the browse button and navigate to where you downloaded the template file.</li>\r\n    <li class="li_number5">Once you have the file selected click &#39;Upload File and Install&#39;</li></li>\r\n    <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; The template is now installed, now let&#39;s set it as the default template:<br />\r\n    </p>\r\n    <li class="li_number6">Navigate through your menu system to Extensions/Template Manager.</li><li class="li_number7">Find the radio button next to the newly installed template.</li><li class="li_number8">Click on the Default button at the top right of the screen and you&#39;re done!</ul>\r\n  </ul>\r\n  <p>&nbsp;</p>\r\n', '', -2, 1, 0, 1, '2007-12-11 19:38:14', 62, '', '2008-07-15 13:11:01', 62, 0, '0000-00-00 00:00:00', '2007-12-11 19:37:21', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 14, 0, 0, '', '', 0, 5084, ''),
(18, 'Configuring The Template''s Settings', 'configuring-the-templates-settings', 'Configuring The Template''s Settings', '<p>This template comes loaded with options that you can use to customize your site exactly how you want it. Here&#39;s how to get to these custom settings:</p><p>&nbsp;</p>   <b><font size="4">Joomla 1.0</font></b><br /><br /><ol> <li>In the backend of Joomla navigate to the menu item Site/Template Manager/Site Templates.</li> <li>Select this template''s radio button.</li> <li>Find the Edit HTML button at the top right of your screen and click it.</li> <li>After clicking the Edit HTML button you will be brought to an editor screen. If you&#39;ve never seen this screen before or have never done any programming relax, just take a deep breath and follow the next few steps.</li> <li>Find the part of the text that looks like this: <br /><br />/////////////////////////////////////////////////////////////////////////////////////// // Template Configuration<br /><br />It should be right in front of you on page load.</li> <li>Begin answering the questions below that line and when you are done click Save at the top.</li> <li>Finally, sit back and relax, you&#39;ve just completed one of the hardest parts of template configuration!</li><br /><br /></ol><img src="http://www.shape5.com/demo/images/template_edit.jpg" alt=" " width="500" height="114" />\r\n\r\n<br /><br />\r\n\r\n<b><font size="4">Joomla 1.5</font></b><br /><br />\r\n\r\n<ol> <li>In the backend of Joomla go menu item Extensions/Template Manager.</li> <li>Click on the title of the template.</li> <li>This will bring you to the template manager screen where you can edit the template''s parameters.</li><li>Click save when you are done</li></ol>\r\n\r\n<br /><br /></ol><img src="http://www.shape5.com/demo/images/template_edit15.jpg" alt=" " width="500" height="156" />\r\n\r\n<br /><br /><br />\r\n<div>I like what I see! I want to <a style="text-decoration:underline" href="http://www.shape5.com/join-now.html" target="_top">join today</a>.</div>', '', -2, 1, 0, 1, '2007-12-11 19:46:04', 62, '', '2007-12-11 19:48:07', 62, 0, '0000-00-00 00:00:00', '2007-12-11 19:45:45', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 2, 0, 0, '', '', 0, 5021, ''),
(5, 'Joomla! License Guidelines', 'joomla-license-guidelines', '', '<p>This website is powered by <a href="http://www.joomla.org/">Joomla!</a>  The software and default templates on which it runs are Copyright 2005 <a href="http://www.opensourcematters.org/">Open Source Matters</a>.  All other content and data, including data entered into this website and templates added after installation, are copyrighted by their respective copyright owners.</p><p>If you want to distribute, copy or modify Joomla!, you are welcome to do so under the terms of the <a href="http://www.gnu.org/copyleft/gpl.html#SEC1">GNU General Public License</a>.  If you are unfamiliar with this license, you might want to read <a href="http://www.gnu.org/copyleft/gpl.html#SEC4">''How To Apply These Terms To Your Program''</a> and the <a href="http://www.gnu.org/licenses/gpl-faq.html">''GNU General Public License FAQ''</a>.</p>', '', -2, 0, 0, 0, '2004-08-19 20:11:07', 62, '', '2011-08-25 13:54:36', 62, 0, '0000-00-00 00:00:00', '2004-08-19 00:00:00', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 1, '', '', 0, 19, 'robots=\nauthor='),
(22, 'Easy To Follow Steps', 'easy-to-follow-steps', 'Easy To Follow Steps', '<p>We go through great lengths to make sure our templates are easy to setup by means of very user friendly step by step questions in the template configuration. The Native 1.5 version uses the same questions but through the Joomla interface. Below are some generic examples to show how easy our setup is to follow:</p><p>&nbsp;</p>\r\n\r\n<div class="code">\r\n//What width in pixels would you like the width of the body to be?\r\n<br/>	$s5_body_width = "975";\r\n<br/><br/>\r\n//What width in pixels would you like the left column to be?\r\n<br/>	$s5_left_width = "250";	\r\n<br/><br/>	\r\n//What width in pixels would you like the right column to be?\r\n<br/>	$s5_right_width = "237";\r\n<br/><br/>\r\n//S5 Box Drop Down - What text would you like for the button that closes the s5 box drop down?\r\n<br/>	$s5_boxdrop = "Close";\r\n\r\n</div>\r\n\r\n<br/>\r\n\r\n\r\n\r\n<p>Those are just some examples there are plenty of easy to follow steps in the template configuration of all our templates to ensure that your template is setup correctly in a very easy to follow manner.&nbsp;</p>', '', -2, 1, 0, 1, '2007-12-11 21:14:30', 62, '', '2008-07-14 23:16:23', 62, 0, '0000-00-00 00:00:00', '2007-12-11 21:14:14', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 3, 0, 0, '', '', 0, 4094, ''),
(24, 'Custom Page and Column Widths', 'custom-page-and-column-widths', 'Custom Page and Column Widths', '<p>Easily set your own widths! This template gives you the ability to set your own \r\nwidth for:</p><br/>\r\n<p>1. Page body</p>\r\n<p>2. Left column</p>\r\n<p>3. Right column</p>\r\n<Br/>\r\n<p>All of this is done very easily in the template configuration.</p>\r\n<p>&nbsp;</p>\r\n<p align="center">\r\n<img style="border:solid 1px #dedede" border="0" src="images/customwidth.png"/></p>\r\n<br />', '', -2, 1, 0, 1, '2007-12-11 21:25:09', 62, '', '2008-07-14 23:14:28', 62, 0, '0000-00-00 00:00:00', '2007-12-11 21:24:39', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 10, 0, 0, '', '', 0, 4766, ''),
(39, 'SQL Dumps/Site Shapers', 'sql-dumpssite-shapers', 'SQL Dumps/Site Shapers', '<h3>Site Shaper</h3>\r\n<br/>\r\nThis month we introduce Shape 5 Site Shapers.  So what are Site Shapers? They are quick installs of Joomla combined with all the modules, images, etc used on our demo. Within a few minutes you can have your site up, running and looking just like our demo. No more importing SQL dumps and installing modules.  Just head on over to the download section of this template and grab a Site Shaper.\r\n<Br/><br/>\r\nBoth Joomla 1.0.x and Joomla 1.5 Site Shapers are available<br/><br/>\r\n<div class="red_box">NOTE: The Site Shapers include the Community builder component.  1.5 version is running in legacy mode due to no release of a native 1.5 version.</div><Br/><br/>\r\n\r\n<h3>SQL Dumps</h3>\r\n<br/>\r\nIt is highly recommended that you use a Site Shaper if you want to get your site looking like our demos.  If you just want the data we have used the an SQL dump is for you. \r\n\r\n<ul class="ul_bullet">\r\n<li>Login to your phpmyadmin via cpanel or another server database admin panel.</li>\r\n<li>Navigate to the database your Joomla install is using</li>\r\n<li>Select all tables and drop them. (NOTE: This will delete all your website data on this current Joomla install)</li>\r\n<li>Next, click import and import the SQL dump we provide</li>\r\n<li>Now you are done, just login via your Joomla admin with username=admin and password=admin</li>\r\n</ul> \r\n<Br/><br/>\r\n<div class="red_box">NOTE: The SQL Dumps include the Community builder component.  This means you will have to download and install the component before importing the SQL dump.</div><Br/><br/>\r\n', '', -2, 1, 0, 1, '2008-07-15 13:16:58', 62, '', '2008-07-15 13:24:54', 62, 0, '0000-00-00 00:00:00', '2008-07-15 13:11:52', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 6, 0, 0, '', '', 0, 6, ''),
(19, 'LyteBox Setup', 'lytebox-setup', 'LyteBox Setup', '<br />\r\n\r\n\r\n<p><b><font size="4">The already enabled LyteBox feature gives your site a \r\ndazzling picture display!</font></b></p>\r\n<p>Make sure to click on each of the examples.</p>\r\n<p>LyteBox comes pre-installed with this template just follow the tutorials below to setup your images.</p><Br/>\r\n<p><b><font size="4">Single Image Example</font></b></p>\r\n\r\n\r\n\r\n\r\n<a href="http://www.shape5.com/demo/images/large1.jpg" rel="lytebox" title="Aliquam laoreet elementum tellus." style="text-decoration: none"> \r\n<img class="boxed" src="http://www.shape5.com/demo/images/small1.jpg" alt="one" width="214" height="61" align="top" /></a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<p>To enable use the following around any image:</p>\r\n<p>&lt;a href=&quot;http://www.yoursite.com/images/popup.jpg&quot; rel=&quot;lytebox&quot; title=&quot;Your \r\nDescription.&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;</p>\r\n<Br/><p><b><font size="4">Grouped Images Example</font></b></p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<a href="http://www.shape5.com/demo/images/large1.jpg" rel="lytebox[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small1.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n<a href="http://www.shape5.com/demo/images/large2.jpg" rel="lytebox[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small2.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n<a href="http://www.shape5.com/demo/images/large3.jpg" rel="lytebox[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small3.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<p>To enable use the following around any group of images:</p>\r\n<p>&lt;a href=&quot;http://www.yoursite.com/images/popup1.jpg&quot; rel=&quot;lytebox[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail1.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;<br />\r\n&lt;a href=&quot;http://www.yoursite.com/images/popup2.jpg&quot; rel=&quot;lytebox[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail2.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;<br />\r\n&lt;a href=&quot;http://www.yoursite.com/images/popup3.jpg&quot; rel=&quot;lytebox[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail3.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;</p>\r\n<br/><p><b><font size="4">Slideshow Example</font></b></p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n<a href="http://www.shape5.com/demo/images/large1.jpg" rel="lyteshow[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small1.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n<a href="http://www.shape5.com/demo/images/large2.jpg" rel="lyteshow[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small2.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n<a href="http://www.shape5.com/demo/images/large3.jpg" rel="lyteshow[gallery]" title="Loirem le as telaiu proen." style="text-decoration: none">\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small3.jpg" alt="Description" width="214" height="61" align="top" /></a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<p>To enable use the following around any group of images:</p>\r\n\r\n&lt;a href=&quot;http://www.yoursite.com/images/popup1.jpg&quot; rel=&quot;lyteshow[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail1.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;<br />\r\n&lt;a href=&quot;http://www.yoursite.com/images/popup2.jpg&quot; rel=&quot;lyteshow[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail2.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;<br />\r\n&lt;a href=&quot;http://www.yoursite.com/images/popup3.jpg&quot; rel=&quot;lyteshow[gallery]&quot; \r\ntitle=&quot;Your Description&quot;&gt;&lt;p align=&quot;center&quot;&gt;&lt;img class=&quot;boxed&quot; src=&quot;http://www.yoursite.com/images/thumbnail3.jpg&quot; \r\nalt=&quot;Description&quot; width=&quot;214&quot; height=&quot;61&quot; /&gt;&lt;/p&gt;&lt;/a&gt;</p>\r\n<Br/><p><b><font size="4">Advanced</font></b></p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<p>You can also change the effects of each display above. To edit these settings \r\nedit the file templates/duoplate/js/lytebox.js. Look for the Configuration \r\nsection about 40 lines down.</p>\r\n<p>&nbsp;</p>\r\n\r\n\r\n<br />\r\n\r\n\r\n<div class="blue_box">I like what I see! I want to <a style="text-decoration:underline" href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</div><br />', '', -2, 1, 0, 1, '2007-12-11 19:49:11', 62, '', '2008-07-14 23:18:22', 62, 0, '0000-00-00 00:00:00', '2007-12-11 19:48:50', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 22, 0, 0, '', '', 0, 8419, ''),
(12, 'Typography', 'typography', 'Typography', '<blockquote><p>This is a sample blockquote. Use <strong>&lt;blockquote&gt;&lt;p&gt;Your content goes \r\nhere!&lt;/p&gt;&lt;/blockquote&gt;</strong> to create a blockquote.</p></blockquote>\r\n\r\n<br />\r\n\r\n<div class="red_box">This is a styled box. Use <strong>&lt;div class=&quot;red_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="blue_box">This is a styled box. Use <strong>&lt;div class=&quot;blue_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="green_box">This is a styled box. Use <strong>&lt;div class=&quot;green_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="yellow_box">This is a styled box. Use <strong>&lt;div class=&quot;yellow_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n<div class="orange_box">This is a styled box. Use <strong>&lt;div class=&quot;orange_box&quot;&gt;Your content \r\ngoes here!&lt;/div&gt;</strong></div>\r\n\r\n<br />\r\n\r\n\r\n\r\nThis is an image with the "boxed" class applied:<br /><br />\r\n\r\n<img class="boxed" src="http://www.shape5.com/demo/images/small1.jpg" alt=""></img>\r\n<br />\r\n\r\n<br />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n\r\n<br />\r\n\r\n<div class="code">This is a sample code div. Use <strong>&lt;div \r\n  class=&quot;code&quot;&gt;Your content goes here!&lt;/div&gt;</strong> to create a code div.<br /><br />#s5_code { width: 30px; color: #fff; line-height: 45px; } </div>\r\n\r\n<br />\r\n\r\n<ol>\r\n<li>This is an <strong>Ordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ol>\r\n\r\n<br />\r\n\r\n<ul>\r\n<li>This is an <strong>Unordered List</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class="ul_arrow">\r\n<li>This is an <strong>Unordered List with class ul_arrow</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n\r\n<br />\r\n\r\n<ul class="ul_star">\r\n<li>This is an <strong>Unordered List with class ul_star</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class="ul_bullet">\r\n<li>This is an <strong>Unordered List with class ul_bullet</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\n<ul class="ul_bullet_small">\r\n<li>This is an <strong>Unordered List with class ul_bullet_small</strong></li>\r\n<li>Congue Quisque augue elit dolor nibh.</li>\r\n<li>Condimentum elte quis.</li>\r\n<li>Opsum dolor sit amet consectetuer.</li>\r\n</ul>\r\n\r\n<br />\r\n\r\nThe following list will support lists up to number 9:\r\n<br /><br />\r\nThis is an <strong>Unordered List with class numbers</strong>\r\n<br/><br/>\r\n<ul class="numbers">\r\n\r\n<li class="li_number1">This is a sample styled number list <strong>&lt;li class=&quot;li_number1&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number2">This is a sample styled number list <strong>&lt;li class=&quot;li_number2&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number3">This is a sample styled number list <strong>&lt;li class=&quot;li_number3&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n<li class="li_number4">This is a sample styled number list <strong>&lt;li class=&quot;li_number4&quot;&gt;Your content \r\ngoes here!&lt;/li&gt;</strong></li>\r\n\r\n</ul>\r\n\r\n<br />\r\n\r\n', '', -2, 1, 0, 1, '2007-12-05 11:25:14', 62, '', '2008-07-14 21:58:39', 62, 0, '0000-00-00 00:00:00', '2007-12-05 11:24:52', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 18, 0, 0, '', '', 0, 11276, ''),
(38, 'Tool Tip Setup', 'tool-tip-setup', 'Tool Tip Setup', '<br/>\r\n<strong>\r\nDemo 1:\r\n</strong>\r\n<br />\r\n<div class="code">\r\n&lt;a onmouseover="Tip(''This is a sample tooltip.'', WIDTH, 140, OPACITY, 80, ABOVE, true, OFFSETX, 1, FADEIN, 200, FADEOUT, 300,SHADOW, true, SHADOWCOLOR, ''#000000'',SHADOWWIDTH, 2, BGCOLOR, ''#000000'',BORDERCOLOR, ''#000000'',FONTCOLOR, ''#FFFFFF'', PADDING, 9)" href="http://www.shape5.com/demo/etensity/"><br/><br/>\r\n&lt;img class="boxed2" alt="" src="http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg"/><br/><br/>\r\n&lt;/a>\r\n</div>\r\n\r\n<br/>\r\n\r\n\r\n\r\n\r\n<a onmouseover="Tip(''This is a sample tooltip.'', WIDTH, 140, OPACITY, 80, ABOVE, true, OFFSETX, 1, FADEIN, 200, FADEOUT, 300,SHADOW, true, SHADOWCOLOR, ''#000000'',SHADOWWIDTH, 2, BGCOLOR, ''#000000'',BORDERCOLOR, ''#000000'',FONTCOLOR, ''#FFFFFF'', PADDING, 9)" href="http://www.shape5.com/demo/etensity/">\r\n\r\n<img class="boxed2" alt="" src="http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg"/>\r\n\r\n</a>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br/>\r\n\r\n\r\n<br/><br />\r\n<strong>\r\nDemo 2:\r\n</strong>\r\n<br />\r\n\r\n\r\n\r\n<div class="code">\r\n&lt;a href="index.htm" onmouseover="Tip(''Image Demo<br /> <br />&lt;img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>'')">Demo 2 Image Tool Tip &lt;/a> \r\n</div>\r\n<br/>\r\n<a href="index.htm" onmouseover="Tip(''Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>'')"><strong>Demo 2 Image Tool Tip</strong></a><br/><br/> \r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<br/>\r\n<strong>\r\nDemo 3:\r\n</strong>\r\n<br />\r\n\r\n\r\n<div class="code">\r\n&lt;a href="#" onmouseover="Tip(''Image Demo&lt;br /> &lt;br />&lt;img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>'',SHADOW, true,  BGCOLOR, ''#000000'', FADEIN, 400, FADEOUT, 400, SHADOWCOLOR, ''#000000'', BORDERCOLOR, ''#000000'',OPACITY, 90,FONTCOLOR, ''#FFFFFF'')">&lt;strong>Demo 3 Image Tool Tip&lt;/strong>&lt;/a>\r\n</div>\r\n\r\n\r\n<a href="#" onmouseover="Tip(''Image Demo<br /> <br /><img src=http://www.shape5.com/demo/smart_blogger/images/tooltip.jpg width=220 height=147>'',SHADOW, true,  BGCOLOR, ''#000000'', FADEIN, 400, FADEOUT, 400, SHADOWCOLOR, ''#000000'', BORDERCOLOR, ''#000000'', OPACITY, 90,FONTCOLOR, ''#FFFFFF'')"><strong>Demo 3 Image Tool Tip</strong></a>\r\n<br/><br/>\r\n\r\n', '', -2, 1, 0, 1, '2008-07-14 22:54:42', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-07-14 22:54:13', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 1, 0, 0, '', '', 0, 1, ''),
(13, 'S5 No-MooMenu With Multiple Effects', 's5-no-moomenu-with-multiple-effects', 'S5 No-MooMenu With Multiple Effects', '<p>The S5 No-MooMenu is one of the most advanced menu systems for Joomla! Unlike \r\nother similar menu systems that use mootools and cause script conflictions with \r\nyour modules and components the S5 No-MooMenu is completely powered by S5 \r\nEffects so your modules and components won''t cause any conflictions using this \r\nmenu system. Just mouse over the top menu and you will notice the menu smoothly \r\nexpand and fade in.</p><br />\r\n<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;\r\n<img border="0" src="images/nomoomenu.png" width="542" height="259"></p><br />\r\n<p><b><font size="4">3 Options:</font></b></p><br />\r\n<ul class="numbers">\r\n<li class="li_number1">S5 No-MooMenu with fade-in effect (<a href="http://www.shape5.com/demo/duoplate/index.php">click here for an example</a>)</li>\r\n<li class="li_number2">S5 No-MooMenu with drop-in effect (<a href="http://www.shape5.com/demo/duoplate/duoplate2/index.php">click here for an example</a>)</li>\r\n<li class="li_number3">Standard Snap-in Suckerfish Menu&nbsp; (<a href="http://www.shape5.com/demo/duoplate/duoplate3/index.php">click here for an example</a>)</li>\r\n\r\n<br /><br />\r\n\r\n<div class="blue_box">I like what I see! I want to <a style="text-decoration:underline" href="http://www.shape5.com/join-now.html" target="_top">JOIN TODAY</a>.</div><br />', '', -2, 1, 0, 1, '2007-12-05 11:32:41', 62, '', '2008-07-14 21:59:52', 62, 0, '0000-00-00 00:00:00', '2007-12-05 11:32:07', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 21, 0, 0, '', '', 0, 16968, ''),
(14, '22 Module Positions', '22-module-positions', '22 Module Positions', '<p>On this page you will see all the module styles and module positions \r\navailable plus how to setup each of them.<br/>for this template. </p><br />\r\n<p><b><font size="3">All modules are fully collapsible!</font></b></p><br />\r\n<p><font size="3"><b>How to install modules and setup module styles:</b></font></p>\r\n<p><font size="4"><b>Joomla 1.0</b></font></p>\r\n<p>\r\n\r\n\r\n\r\n<ol>\r\n<li>Download only module you wish to publish to your site.</li>\r\n<li>In the backend of Joomla navigate to the menu item Installers/Modules.</li>\r\n\r\n<li>Browse for the module''s install file and click Upload File & Install.</li>\r\n\r\n<li>Once the module has installed navigate to the menu item Modules/Site Modules.</li>\r\n\r\n<li>Find the Module just installed and click on it''s title.</li>\r\n\r\n<li>Change any parameters that you wish and be sure to set it to published and publish it to your desired module position.<br /><br /><img border="0" src="http://www.shape5.com/demo/images/mod10pos.png" width="330" height="242"><br /></li><br />\r\n\r\n<li>To apply a module style simply fill in the module class suffix field with any of this template''s included module styles.\r\n<br /><br /><img border="0" src="http://www.shape5.com/demo/images/mod10suf.png" width="330" height="73"><br /></li><br />\r\n\r\n<li>Assign what pages you would like the module to appear on and finally click Save.</li>\r\n\r\n\r\n</ol>\r\n\r\n</p>\r\n\r\n<p><font size="4"><b>Joomla 1.5</b></font></p>\r\n<p>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n<ol>\r\n<li>Download only module you wish to publish to your site.</li>\r\n<li>In the backend of Joomla navigate to the menu item Extensions/Install Uninstall.</li>\r\n\r\n<li>Browse for the module''s install file and click Upload File & Install.</li>\r\n\r\n<li>Once the module has installed navigate to the menu item Extensions/Module Manager.</li>\r\n\r\n<li>Find the Module just installed and click on it''s title.</li>\r\n\r\n<li>Change any parameters that you wish and be sure to set it to published and publish it to your desired module position.<br /><br /><img border="0" src="http://www.shape5.com/demo/images/mod15pos.png" width="330" height="242"><br /></li><br />\r\n\r\n<li>To apply a module style simply fill in the module class suffix field with any of this template''s included module styles. This parameter setting is found under Module Parameters on the right side of the screen.\r\n</li>\r\n\r\n<li>Assign what pages you would like the module to appear on and finally click Save.</li>\r\n\r\n\r\n</ol>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n</p>\r\n\r\n', '', -2, 1, 0, 1, '2007-12-05 13:16:18', 62, '', '2008-07-14 17:18:39', 62, 0, '0000-00-00 00:00:00', '2007-12-05 13:16:05', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 13, 0, 0, '', '', 0, 14217, ''),
(34, '3', '3', '3', 'The S5 No-MooMenu is completely powered by our own S5 Effects and comes with drop-in and fade-in effects.', '', -2, 2, 0, 13, '2008-02-11 21:12:06', 62, '', '2008-02-11 21:12:38', 62, 0, '0000-00-00 00:00:00', '2008-02-11 21:11:09', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 2, 0, 0, '', '', 0, 23, ''),
(35, 'Three S5 Box''s to choose from', 'three-s5-boxs-to-choose-from', 'Three S5 Box''s to choose from', '<h3>S5 Box - Drop Down Style</h3><br/>\r\nThis month we introduce a new S5 box style to change things up a bit.  Once you click the button to active the box, you will notice it slide down from the top of the screen while the background fades in and vice versa on deactivation.\r\n\r\nTo make the S5 Box visible simply publish any module to the ''toolbar'' position. If your content is too tall and does not fit the height of this drop down S5 Box, scroll bars will automatically appear.\r\n\r\nNOTE: This position and the "more information" button will not show unless a module is published to the toolbar position. The "more information" text can be changed via the index.php file in J1.0 or the template manager in J1.5.\r\n<br/>\r\n<br/>\r\n<strong>Preview of S5 Box - Drop Down Style</strong><br/><br/>\r\n<img src="images/dropdown.png" alt="S5 Box"/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n\r\n\r\n\r\n\r\n<h3>S5 Box - Popup Style 1</h3><br/>\r\nThe S5 box popup style is our classic S5 Box that pops up while the background fades in.\r\n\r\nThe S5 Box 1 has a module position of "cpanel". The "register" text can be changed via the index.php file in J1.0 or the template manager in J1.5. You can also specify to either show or hide this button if a user is logged in. So if you want to use a registration module (like the CB one we provide) and then when a user is logged in have this button disappear the S5 Box 1 position allows you to do so (this is enabled by default).\r\n\r\nFeatures:\r\n\r\n-Specify width (via index.php file in J1.0 or the template manager in J1.5)\r\n-Height automatically adjusts to content.\r\n-Change button text\r\n-Choose to hide module button and position when a user is logged in\r\n\r\nNOTE: This position and the "login" button will not show unless a module is published to the debug position. \r\n<br/>\r\n<br/>\r\n<strong>Preview of S5 Box - Popup Style 1</strong><br/><br/>\r\n<img src="images/popup1.png" alt="S5 Box"/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n<br/>\r\n\r\n<h3>S5 Box - Popup Style 2</h3><br/>\r\nThe S5 box popup style is our classic S5 Box that pops up while the background fades in.\r\n\r\nThe S5 Box 2 has a module position of "login". The "login" text can be changed via the index.php file in J1.0 or the template manager in J1.5. "logout" text can also be added for this position. When a user is logged in the button text will change to "logout".\r\n\r\nFeatures:\r\n\r\n-Specify width (via index.php file in J1.0 or the template manager in J1.5)\r\n-Height automatically adjusts to content.\r\n-Change button text\r\n-Choose text to show for button when user is logged in\r\n\r\nNOTE: This position and the "login" button will not show unless a module is published to the debug position. \r\n<br/>\r\n<br/>\r\n<strong>Preview of S5 Box - Popup Style 2</strong><br/><br/>\r\n<img src="images/popup2.png" alt="S5 Box"/><br/><br/><br/>\r\n<br/>\r\n<br/>\r\n\r\n<div class="blue_box">I like what I see! I want to <a target="_top" href="http://www.shape5.com/join-now.html" style="text-decoration: underline;">JOIN TODAY</a>.</div>', '', -2, 1, 0, 1, '2008-02-14 10:39:03', 62, '', '2008-07-14 22:16:20', 62, 0, '0000-00-00 00:00:00', '2008-02-14 10:38:41', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 18, 0, 0, '', '', 0, 4717, ''),
(16, 'S5 Frontpage Slide Module', 's5-frontpage-slide-module', 'S5 Frontpage Slide Module', '<br />The S5 Frontpage Slide Module can be used on any template!  It holds up to <strong>10</strong> actual module positions so you can publish any of your favorite modules to one of the slides and keep your site clean and consolidated while giving it some eye candy.  The following is a quick list of features that are included with the module: <br /><br /> <ul class="ul_star"> <li>Choose Mootools slide in or S5 Effects snap in or fade in effects (Choose S5 Effects to guarantee no script conflictions)</li> <li>Set button backgrounds and hovers</li> <li>Position buttons to the left or right of the sliding modules</li> <li>Holds up to 10 module positions</li> <li>Enable/Disable shadows</li> <li>Specify the width and height of the module</li> <li>XHTML Valid</li> </ul> <br /> <br />   The following is a demo of the S5 Frontpage Slide Module with the Fade effect enabled, to see the scroll effect click the home button in the upper left hand corner.  <br /><br /> {loadposition bottom}    <br /><br /> The following is a screenshot of what the admin side of the module looks like: <br /><br />  <img src="images/s5slidemod.png" border="0" alt="S5 Slide Admin" />  <br /> <br /> <p><strong>Joomla 1.0  requires you to setup 10 new module positions, but it''s easy and only takes seconds. Here''s how you do it:</strong></p>   <br /> <ul class="ul_bullet"> <li>Login to the backend of Joomla.</li> <li>Navigate through the menu system to Site/Template Manager/Module Positions</li> <li>Starting at the first blank position field enter s5_fs_1 as a name (Joomla main content is tab1).</li> <li>Continue adding s5_fs_2, s5_fs_3 in the next fields up to s5_fs_10</li> <li>Click the save button in the upper right hand corner and you''re done!</li> </ul>  <br /><br />   <div class="blue_box">I like what I see! I want to <a href="../../../join-now.html" target="_top">JOIN TODAY</a>.</div>', '', -2, 1, 0, 1, '2007-12-10 18:30:18', 62, '', '2008-07-16 05:52:38', 62, 0, '0000-00-00 00:00:00', '2007-12-10 18:29:57', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 42, 0, 0, '', '', 0, 8409, 'robots=\nauthor='),
(27, 'NEW! CB Register Module', 'new-cb-register-module', 'NEW! CB Register Module', '<p>&nbsp;</p>\r\nThe new CB Register module is pretty much a copy of the registration page that community builder uses.  Having this page converted into a module allows you to put the registration page in a popup or similar lytebox window as we have done (click the register button in the upper right corner).  The CB registration page would sometimes cause a suckerfish menu in IE6 to flicker, in this module we have fixed this problem.  Below is a list of some of the module features:<br/><br/>\r\n\r\n<ul class="ul_star">\r\n<li>Uses same anti-spam method as Community builder registration page</li>\r\n<li>Choose to enable terms and conditions</li>\r\n<li>Specify terms and conditions URL</li>\r\n<li>Fix''s suckerfish menu problem for IE6</li>\r\n<li>XHTML Valid</li>\r\n</ul>\r\n\r\n\r\n<Br/><br/>\r\nScreenshot of CB Regsiter module, to demo click the top right "register" button on this page:<br/><br/>\r\n<img src="images/register.png" alt="s5slide" />', '', -2, 1, 0, 1, '2007-12-11 21:36:14', 62, '', '2008-07-15 13:04:15', 62, 0, '0000-00-00 00:00:00', '2007-12-11 21:35:51', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 16, 0, 0, '', '', 0, 6509, ''),
(36, 'How To Setup the Search Box', 'how-to-setup-the-search-box', 'How To Setup the Search Box', '<br />\r\n<p><b><font size="4">Search Setup</font></b></p><br/>\r\n<p><font size="4"><b>&nbsp;&nbsp;&nbsp;&nbsp;\r\n<img border="0" src="images/search.png"/></b></font></p>\r\n<ul class="ul_arrow">\r\n<li>Publish the default Joomla search module to the ''top'' position.</li>\r\n<li>Do not show the search button.</li>\r\n</ul>\r\n\r\n<br />\r\n', '', -2, 1, 0, 1, '2008-02-14 15:10:56', 62, '', '2008-07-15 13:23:44', 62, 0, '0000-00-00 00:00:00', '2008-02-14 15:10:36', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 19, 0, 0, '', '', 0, 2497, ''),
(37, 'NEW! S5 News Ticker', 'new-s5-news-ticker', 'NEW! S5 News Ticker', 'The S5 News Ticker is quite similar to our Image Fader module except instead of images being shown, only one line of text is displayed at a time.  Below is a list of some of the News Ticker features:<br /><br />  <ul class="ul_star"> <li>Powered by S5 Effects so you will experience no script conflictions</li> <li>Up to ten lines of text</li> <li>HTML can be used too</li> <li>Set display time</li> <li>Set rotation speed</li> <li>XHTML Valid</li> </ul>  <br /><br /> Below is a demo of the image fader: <br /> <br />  {loadposition user9}', '', -2, 1, 0, 1, '2008-03-13 21:00:55', 62, '', '2008-07-16 05:56:08', 62, 0, '0000-00-00 00:00:00', '2008-03-13 20:59:37', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 5, 0, 0, '', '', 0, 1860, 'robots=\nauthor='),
(32, '1', '1', '1', 'Easily make this template unique and create your own background in just a few steps. Look under tutorials to learn how.', '', -2, 2, 0, 13, '2008-02-11 21:06:40', 62, '', '2008-02-11 21:09:49', 62, 0, '0000-00-00 00:00:00', '2008-02-11 21:06:23', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 6, 0, 0, '', '', 0, 23, ''),
(33, '2', '2', '2', 'Tired of script conflictions from other club''s templates and your modules? S5 Effects means no script conflictions!', '', -2, 2, 0, 13, '2008-02-11 21:10:34', 62, '', '2008-02-11 21:10:56', 62, 0, '0000-00-00 00:00:00', '2008-02-11 21:09:52', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 2, 0, 0, '', '', 0, 24, ''),
(29, 'CommPortal', 'commportal', 'CommPortal', 'CommPortal is Shape 5''s first template geared toward the Community Builder component.  We introduce for the first time a <strong>"Logged Out Mode"</strong> option which restricts users to only several items before registering and logging in.  This month we include <strong>3 S5 Box''s</strong>, two of which are the classic popup and the third is a new drop down style, 22 module positions, custom background images and much more! <br /> <br /> We are proud to announce the addition of <strong>Site Shaper''s</strong> which are pretty much quick installs of all demo content, images and modules.  In addition to this we have released three new modules:  <strong>S5 Frontpage Slide, S5 News Ticker and the S5 CB Register module</strong>.  Be sure to demo these new modules and check out all features we packed into them! ', '', -2, 1, 0, 1, '2007-12-12 13:41:14', 62, '', '2011-08-25 19:13:40', 62, 0, '0000-00-00 00:00:00', '2007-12-12 13:39:40', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 55, 0, 0, '', '', 0, 3189, 'robots=\nauthor=0'),
(30, 'Set your background color/image', 'set-your-background-colorimage', 'Set your background color/image', 'The Commportal template is laid out in PNGs this means you can easily change the background color or even image via the index.php file for Joomla 1.0.x or the template manager for Joomla 1.5 Native.  We tried to make things as easy as possible so we used PNGs to layout the template but you may have to edit a few images (if you want to change colors or you can''t get your background to display correctly with the current color scheme), the menu hover images etc due to the template design.  Sliced PSDs are provided to make image edits as easy as possible.\r\n<br/>\r\n<br/>\r\n<strong>For Joomla 1.0.x look for the following at the top of the index.php file:</strong><br/>\r\n<div class="code">\r\n//Enter the URL to a background image that will repeat throughout the body of the template\r\n	<br/>$s5_repeatback = "images/bodyback.jpg";	\r\n	\r\n<br/>//Enter the color in HEX of the background you would like for the template body\r\n	<br/>$s5_colorback = "#FFFFFF";	\r\n</div>\r\n<br/>\r\n<strong>For Joomla 1.5 look for the same lines of configuration under "extensions > template manager" select commportal then click edit and on the following screen (right hand side) you notice the background options.</strong><br/>', '', -2, 1, 0, 1, '2008-02-06 19:08:42', 62, '', '2008-07-14 23:13:31', 62, 0, '0000-00-00 00:00:00', '2008-02-06 19:08:26', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 33, 0, 0, '', '', 0, 5798, ''),
(40, 'Logged Out Mode', 'logged-out-mode', 'Logged Out Mode', 'This month we introduce for the first time in the Joomla template community an option to enabled a logged out mode. The logged out mode will only show the homepage with a few modules. All other pages that a user tries to navigate to will throw up a message asking them to register or login via the homepage. This option can be enabled or disabled via the template configuration. \r\n<br/><br/>\r\n<div class="blue_box">\r\n<center>Click here to demo the loggout out mode</center>\r\n</div>\r\n<br/>\r\n<strong>Screenshot of Logged out Mode:</strong>\r\n<br/>\r\n<img src="images/loggedout.jpg" alt="logged out"/>\r\n<br/>\r\n<br/>\r\n<strong>Screenshot of Logged out message when any page but the homepage is viewed:</strong>\r\n<br/>\r\n<img src="images/message.jpg" alt="logged out"/>\r\n<br/>\r\n<br/><br/>\r\n\r\n<h3>Module positions included for loggedout homepage mode:</h3><br/>\r\n<ul class="ul_bullet">\r\n<li>banner</li>\r\n<li>ticker1</li>\r\n<li>left</li>\r\n<li>user1</li>\r\n<li>user2</li>\r\n<li>user8 (replaces Joomla main content area)</li>\r\n<li>right</li>\r\n<li>ticker2</li>\r\n<li>cpanel</li>\r\n<li>debug</li>\r\n<li>toolbar</li>\r\n</ul>\r\n\r\n<br/><br/>\r\n<h3>Joomla 1.0.x</h3>\r\n\r\n<div class="code">\r\n// Enter logged in mode.  This will show only a select few module positions when a user is not logged in, restricting his site acces.\r\n	<br/>$s5_loggedin = "no";  \r\n</div>\r\n<br/><br/>\r\n\r\n<h3>Joomla 1.5</h3>\r\n<br/>\r\nFor Joomla 1.5 look for the same lines of configuration under "extensions > template manager" select commportal then click edit and on the following screen (right hand side) you notice the logged out mode options.\r\n', '', -2, 1, 0, 1, '2008-07-15 15:06:45', 62, '', '2008-07-15 15:46:44', 62, 0, '0000-00-00 00:00:00', '2008-07-15 15:05:49', '0000-00-00 00:00:00', '', '', 'pageclass_sfx=\nback_button=\nitem_title=1\nlink_titles=\nintrotext=1\nsection=0\nsection_link=0\ncategory=0\ncategory_link=0\nrating=\nauthor=\ncreatedate=\nmodifydate=\npdf=\nprint=\nemail=\nkeyref=\ndocbook_type=', 11, 0, 0, '', '', 0, 15, ''),
(41, 'Administrativo', 'administrativo', '', '<h1>Administrativo.</h1>', '', 1, 0, 0, 0, '2011-12-05 19:22:24', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:22:24', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 9, '', '', 0, 4, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(42, 'Informacion General', 'informacion-general', '', '<h1><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1" style="background: url(images/group.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Informacion General</a></h1>\r\n<p>El Sistema de Gestión de la Calidad tiene como objetivo organizar y     normalizar el trabajo actual de la entidad. Su implantación se basa en     la implementación de la Norma ISO 9001-2008, elaborada por la  Organización    Internacional de Estandarización (ISO). La misma es  adoptada (no adaptada)    por Cuba, convirtiéndose para nuestro país en  la Norma Cubana    NC-ISO 9001-2008.</p>\r\n<p>Tiene como alcance su implementación en la oficina provincial y en  las    oficinas municipales de Pinar del Río y Consolación del Sur, las     cuales trabajan sobre una política de la calidad elaborada y aprobada     por el Comité de Calidad de la oficina provincial, que plantea:</p>\r\n<p>"Garantizar los servicios estadísticos y la gestión de información     relevante, mediante una adecuada captación y procesamiento, en los  ámbitos    económico, social, demográfico y medio ambiental, así como     su difusión de acuerdo con los requerimientos del país, siendo     capaces de satisfacer los requisitos de nuestros usuarios, a través de     la implantación, mantenimiento y mejora continua del Sistema de  Gestión    de la Calidad, según la NC-ISO 9001:2008."</p>\r\n<p><strong>Nota:</strong> Para más detalles, descargar documento <strong>Manual    de la Calidad</strong> adjuntado al final de esta página.</p>\r\n<p>La NC-ISO 9001-2008 está compuesta por ocho capítulos, de los     cuales solo cinco son auditables. Estos últimos a su vez están     conformados por requisitos que la entidad debe cumplir. A continuación     exponemos la lista de estos cinco capítulos con sus correspondientes     requisitos.</p>\r\n', '\r\n<p> </p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><span style="text-decoration: underline;">10 Mandamientos de la calidad</span></strong></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">1.<span style="font: 7.0pt "> </span><span lang="ES">No permita que algo que salió mal se convierta en el primer tema del día cuando vaya a planear algo. Comente al máximo sus planes en el sentido de tornar su trabajo cada vez más productivo. </span><strong><span lang="PT-BR">Pensar en positivo es calidad!</span></strong></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">2.<span style="font: 7.0pt "> </span><span lang="PT-BR">Al entrar al edificio de su empresa, corresponda con un saludo a cada uno que se encuentre, sea o no colega de su área. <strong>Ser educado es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;"><span lang="PT-BR"><strong> </strong></span>3.<span style="font: 7.0pt "> </span><span lang="PT-BR">Sea metódico al abrir su archivo, al encender su computadora, al pasar informaciones, etc. Comience recordando las notas del día anterior.<br /></span><strong><span style="font-size: 30.0pt; line-height: 115%; mso-fareast-font-family: +mn-ea; mso-bidi-font-family: +mn-cs; color: black; mso-font-kerning: 12.0pt; text-shadow: auto; mso-ansi-language: PT-BR;" lang="PT-BR"> </span></strong><strong><span lang="PT-BR">Ser organizado es calidad!</span></strong></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">4.<span style="font: 7.0pt "> </span><span lang="PT-BR">No se deje llevar por la primera información de error recibida de quien, tal vez, no conozca todos los detalles. Recopile más datos que le permitan arribar a un juicio correcto sobre el asunto.<strong>Ser prevenido es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">5.<span style="font: 7.0pt "> </span><span lang="PT-BR">Cuando sea solicitado por alguien, intente posponer su propia tarea, pues quien acude a Ud. debe estar precisando bastante de su ayuda y en Ud. depositó su confianza.  El estará feliz por la ayuda que Ud. le haya brindado. <strong>Ser atento es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">6.<span style="font: 7.0pt "> </span><span lang="PT-BR">No deje de alimentarse a la hora de almuerzo. Puede ser hasta un pequeño bocado, pero respete sus necesidades. Aquella tarea urgente puede esperar unos minutos. Si Ud. enferma, decenas de tareas tendrán que aguardar a su recuperación, menos aquellas que acabarán sobrecargando a sus colegas. <strong>Respetar la salud es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">7.<span style="font: 7.0pt "> </span><span lang="PT-BR">Dentro de lo posible, intente planificarse para los próximos 10 días, tanto para asuntos laborales, como sociales o personales. No esté cambiando las fechas y horas a cada momento, principalmente a pocas horas de un evento del tipo que sea. Recuérdese que con ello afectará el horario a varios de sus colegas. <strong>Cumplir lo planificado es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">8.<span style="font: 7.0pt "> </span><span lang="PT-BR">Al comenzar un evento lleve todo lo que sea preciso de acuerdo a la ocasión, principalmente sus ideas. ¡Divúlguelas sin recelo! Lo más que puede pasar es que alguien con poder o del equipo no las acepte. Tal vez más adelante, en 2 o 3 meses, Ud. tenga la oportunidad de mostrar que estaba en lo cierto. Es de sabios saber esperar. <strong>Tener paciencia es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">9.<span style="font: 7.0pt "> </span><span lang="PT-BR">No prometa lo que está fuera de su alcance solo para impresionar a quien lo escucha.</span><span lang="PT-BR"> </span><span lang="PT-BR">Si quedara en deuda un día, echaría por tierra el concepto que le llevó años construir. <strong>Decir la verdad es calidad!</strong></span></p>\r\n<p class="MsoNormal" style="margin-left: 36.0pt; text-align: justify; text-indent: -18.0pt; mso-list: l0 level1 lfo1;">10.<span style="font: 7.0pt "> </span><span lang="PT-BR">Al salir del trabajo, ¡no se lo lleve consigo! Piense lo bueno que va a ser llegar a casa y compartir con su familia o sus amigos que le ayudarán a ganar esa seguridad que necesita para  desarrollar sus tareas equilibradamente. <strong>Amar a la familia y a sus amigos es la mayor calidad!</strong></span></p>\r\n<p> </p>', 1, 0, 0, 0, '2011-12-05 19:51:05', 62, '', '2011-12-07 13:15:52', 62, 0, '0000-00-00 00:00:00', '2011-12-05 19:51:05', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 9, 0, 8, '', '', 0, 21, 'robots=\nauthor='),
(43, 'Auditoría de la Información.', 'auditoria-de-la-informacion', '', '<h2><strong>Introducción</strong></h2>\r\n<p>Joomla! es un Sistema de Gestión de Contenidos (CMS) reconocido mundialmente, que le<br />ayuda a construir sitios web y otras aplicaciones en línea potentes. Lo mejor de todo, es que<br />Joomla! es una solución de código abierto y está disponible libremente para cualquiera que<br />desee utilizarlo.</p>\r\n<h2><strong>Objetivos del Manual de Usuario</strong></h2>\r\n<p><strong>Los objetivos del Manual del Usuario son:</strong></p>\r\n<ul>\r\n<li>Proporcionar una guía a los usuarios de cómo navegar en la intranet.</li>\r\n</ul>\r\n<ul>\r\n<li>Facilita los conocimientos básicos para las actividades que se pueden o no realizar dentro de la interfaz de usuario.</li>\r\n</ul>\r\n<ul>\r\n<li>Muestra a los usuarios todos los componentes por lo que está conformado el diseño de la intranet.</li>\r\n</ul>\r\n<h2><strong>Definiciones</strong></h2>\r\n<p><strong>Usuario de Joomla:</strong><br />Un Usuario de Joomla tiene una serie de permisos predefinidos, es decir las tareas que<br />puede realizar. Por eso, en el contexto de gestión de un sitio web, dependiendo del modo en<br />que el propietario del sitio decida delegar las responsabilidades, se definirán unos u otros tipos<br />de usuarios Joomla.<br /><strong>Jerarquía de Contenido en Joomla</strong><br />La estructura del contenido en un sitio web Joomla! está organizada en un orden jerárquico en<br />base a Secciones, Categorías y Artículos de Contenido. En la práctica, una Sección puede<br />tener una o más Categorías y una Categoría puede tener uno o más Artículos de Contenido. más Categorías y una Categoría puede tener uno o más Artículos de Contenido.</p>\r\n<p><strong>¿Qué es un sistema de gestión de contenido (CMS)?</strong></p>\r\n<p>Un CMS es un sistema de software para ordenador que permite organizar y facilitar la creación<br /> de documentos y otros contenidos de un modo cooperativo. Con frecuencia, un CMS es una<br /> aplicación web usada para gestionar sitios web y contenidos web.<br /> Joomla! realiza un gran trabajo gestionando el contenido necesario para que un sitio web<br /> funcione. Pero para mucha gente, el verdadero potencial de Joomla! recae en la arquitectura de<br /> la aplicación, que posibilita que miles de desarrolladores en el mundo puedan crear potentes<br /> add-ons y extensiones.</p>\r\n<hr title="Tipos de Usuarios y Permisos de Acceso " alt="Tipos de Usuarios y Permisos de Acceso" class="system-pagebreak" />\r\n<h1>Capítulo 1. Tipos de Usuarios y Permisos de Acceso</h1>\r\n<p><strong>Los Usuarios de sitios web Joomla! pueden dividirse en dos categorías principales:</strong></p>\r\n<ul>\r\n<li>Invitados</li>\r\n<li>Usuarios Registrados</li>\r\n</ul>\r\n<p>Los Invitados son sencillamente usuarios de Joomla! que han navegado hasta encontrar su<br />sitio web. Dependiendo de cómo el administrador ha configurado el sitio, los invitados podrán<br />navegar libremente por todo el contenido o tener restringido el acceso a cierto tipo de<br />contenidos, reservados para usuarios registrados.</p>\r\n<p><br />Los Usuarios Registrados están registrados en su sitio con un nombre de usuario y contraseña.<br />Este nombre de usuario y contraseña les permite acceder al área restringida del sitio,<br />recibiendo privilegios especiales no disponibles para los invitados. Los usuarios registrados se<br />dividen en dos grupos:</p>\r\n<ol>\r\n<li>Usuarios del Sitio.</li>\r\n<li>Usuarios del Administrador.</li>\r\n<li>Usuarios del sitio</li>\r\n</ol>\r\n<p>Los usuarios del Sitio disfrutan de ciertos derechos adicionales sobre los visitantes, entre los<br />que se puede incluir la capacidad para crear y publicar contenido en el sitio web.<br />Generalmente, nos referimos a estos usuarios como proveedores de contenido ya que su meta<br />principal es la de proveer contenido al sitio web, no la de administrar el sitio o alterar su diseño.</p>\r\n<p><br />Los proveedores de contenido pueden enviar nuevos contenidos directamente mediante la<br />interfaz web, es decir dentro de esta amplia clasificación de proveedores de contenido, existen<br />cuatro niveles específicos, que pueden ser asignados por el administrador del sitio. Estos<br />niveles son:</p>\r\n<ul>\r\n<li>Registrado (Registered), Autor (Autor), Editor (Editor) y Supervisor (Publisher).</li>\r\n<li>Registrado (Registered):</li>\r\n</ul>\r\n<p>Un Usuario Registrado no puede crear, editar o publicar contenido en un sitio Joomla puede<br />enviar nuevos Enlaces Web para ser publicados y puede tener acceso a contenidos<br />restringidos que no están disponibles para los invitados.<br />Autor (Autor):<br />Los Autores pueden crear su propio contenido, especificar ciertos aspectos de cómo se<br />presentará el contenido e indicar la fecha en la que debería publicarse el material.</p>\r\n<hr title="Documentación para descargar" alt="Documentación para descargar" class="system-pagebreak" />\r\n<p> </p>\r\n<h2><strong><br />Tabla de Documentos para consulta</strong></h2>\r\n<p><img src="images/stories/oo.png" border="0" /></p>', '', 1, 0, 0, 0, '2011-12-05 19:51:38', 62, '', '2011-12-06 14:39:23', 62, 0, '0000-00-00 00:00:00', '2011-12-05 19:51:38', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 12, 0, 7, '', '', 0, 33, 'robots=\nauthor='),
(44, 'Captación y Procesamiento de la Información.', 'captacion-y-procesamiento-de-la-informacion', '', '<h1><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1#" style="background: url(images/application_double.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Captación y Procesamiento de la Información.</a></h1>', '', 1, 0, 0, 0, '2011-12-05 19:52:03', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:52:03', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 6, '', '', 0, 5, 'robots=\nauthor='),
(45, 'Demografía y Estadísticas Sociales.', 'demografia-y-estadisticas-sociales', '', '<h1><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1#" style="background: url(images/lock.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Demografía y Estadísticas Sociales.</a></h1>', '', 1, 0, 0, 0, '2011-12-05 19:52:29', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:52:29', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 5, '', '', 0, 4, 'robots=\nauthor='),
(46, 'Gestión de la Información.', 'gestion-de-la-informacion', '', '<p><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1#" style="background: url(images/compress.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión de la Información.</a></p>', '', 1, 0, 0, 0, '2011-12-05 19:53:32', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:53:32', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 4, '', '', 0, 4, 'robots=\nauthor='),
(47, 'Gestión de la Dirección para la Mejora Continua.', 'gestion-de-la-direccion-para-la-mejora-continua', '', '<p><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1#" style="background: url(images/status_online.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión de la Dirección para la Mejora Continua.</a></p>', '', 1, 0, 0, 0, '2011-12-05 19:53:51', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:53:51', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 3, 'robots=\nauthor='),
(48, 'Gestión del Capital Humano.', 'gestion-del-capital-humano', '', '<p><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1#" style="background: url(images/group.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión del Capital Humano.</a></p>', '', 1, 0, 0, 0, '2011-12-05 19:54:10', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2011-12-05 19:54:10', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 3, 'robots=\nauthor='),
(49, 'Sistema Informático.', 'sistema-informatico', '', '<p><a href="index.php?option=com_content&amp;view=frontpage&amp;Itemid=1" style="background: url(images/application_go.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Sistema Informático.</a></p>', '', 1, 0, 0, 0, '2011-12-05 19:54:32', 62, '', '2011-12-05 19:59:43', 62, 0, '0000-00-00 00:00:00', '2011-12-05 19:54:32', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 13, 'robots=\nauthor=');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_content_frontpage`
--

CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_content_frontpage`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_content_rating`
--

CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL DEFAULT '0',
  `rating_sum` int(11) unsigned NOT NULL DEFAULT '0',
  `rating_count` int(11) unsigned NOT NULL DEFAULT '0',
  `lastip` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_content_rating`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_acl_aro`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `section_value` varchar(240) NOT NULL DEFAULT '0',
  `value` varchar(240) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Volcar la base de datos para la tabla `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0),
(30, 'users', '82', 0, 'Auditoria', 0),
(29, 'users', '81', 0, 'Direcion', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_acl_aro_groups`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `lft` int(11) NOT NULL DEFAULT '0',
  `rgt` int(11) NOT NULL DEFAULT '0',
  `value` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Volcar la base de datos para la tabla `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_acl_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(230) NOT NULL DEFAULT '0',
  `value` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_core_acl_aro_map`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_acl_aro_sections`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` varchar(230) NOT NULL DEFAULT '',
  `order_value` int(11) NOT NULL DEFAULT '0',
  `name` varchar(230) NOT NULL DEFAULT '',
  `hidden` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_acl_groups_aro_map`
--

CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL DEFAULT '0',
  `section_value` varchar(240) NOT NULL DEFAULT '',
  `aro_id` int(11) NOT NULL DEFAULT '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(18, '', 30),
(24, '', 29),
(25, '', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_log_items`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL DEFAULT '0000-00-00',
  `item_table` varchar(50) NOT NULL DEFAULT '',
  `item_id` int(11) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_core_log_items`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_core_log_searches`
--

CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL DEFAULT '',
  `hits` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_core_log_searches`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_extwebdav_locks`
--

CREATE TABLE IF NOT EXISTS `jos_extwebdav_locks` (
  `token` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(200) NOT NULL DEFAULT '',
  `expires` int(11) NOT NULL DEFAULT '0',
  `owner` varchar(200) DEFAULT NULL,
  `recursive` int(11) DEFAULT '0',
  `writelock` int(11) DEFAULT '0',
  `exclusivelock` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token`),
  UNIQUE KEY `token` (`token`),
  KEY `path` (`path`),
  KEY `expires` (`expires`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_extwebdav_locks`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_extwebdav_properties`
--

CREATE TABLE IF NOT EXISTS `jos_extwebdav_properties` (
  `path` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(120) NOT NULL DEFAULT '',
  `ns` varchar(120) NOT NULL DEFAULT 'DAV:',
  `value` text,
  PRIMARY KEY (`ns`(100),`path`(100),`name`(50)),
  KEY `path` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_extwebdav_properties`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_groups`
--

CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_menu`
--

CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text,
  `type` varchar(50) NOT NULL DEFAULT '',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `parent` int(11) unsigned NOT NULL DEFAULT '0',
  `componentid` int(11) unsigned NOT NULL DEFAULT '0',
  `sublevel` int(11) DEFAULT '0',
  `ordering` int(11) DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL DEFAULT '0',
  `browserNav` tinyint(4) DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `utaccess` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL DEFAULT '0',
  `rgt` int(11) unsigned NOT NULL DEFAULT '0',
  `home` int(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=111 ;

--
-- Volcar la base de datos para la tabla `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Inicio', 'home-mainmenu-1', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=2\nnum_columns=2\nnum_links=1\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=1\nlink_titles=\nshow_intro=\nshow_section=0\nlink_section=\nshow_category=0\nlink_category=\nshow_author=0\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nshow_hits=\nfeed_summary=\npage_title=CommPortal\nshow_page_title=0\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(2, 'mainmenu', 'News', 'news-mainmenu-2', 'index.php?option=com_content&view=section&id=1', 'component', 0, 26, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\nshow_page_title=1\npageclass_sfx=\nback_button=\ndescription_sec=1\ndescription_sec_image=1\norderby=\nother_cat_show_section=1\nempty_cat_show_section=0\nshow_category_description=1\ndescription_cat_image=1\nshow_categories=1\nshow_empty_categories=0\nshow_cat_num_articles=1\ncat_show_description=1\ndate_format=\nshow_date=\nshow_author=\nshow_hits=\nshow_headings=1\nshow_item_navigation=1\norder_select=1\nshow_pagination_limit=1\ndisplay_num=50\nfilter=1\nfilter_type=title\nunpublished=1\nshow_title=1\n', 0, 0, 0),
(3, 'mainmenu', 'Contact Us', 'contact-us-mainmenu-3', 'index.php?option=com_contact&view=category', 'component', 0, 26, 7, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\npageclass_sfx=\nback_button=\nshow_page_title=1\npage_title=\ncatid=0\nother_cat_show_section=1\nshow_categories=1\ncat_show_description=1\nshow_cat_num_articles=1\nshow_description=1\ndescription_text=\nimage=-1\nimage_align=right\nshow_headings=1\nposition=1\nshow_email_icon=0\ntelephone=1\nfax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsessionCheck=1\nshow_title=1\n', 0, 0, 0),
(23, 'mainmenu', 'Links', 'links-mainmenu-23', 'index.php?option=com_weblinks&view=categories', 'component', 0, 26, 4, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\npageclass_sfx=\nback_button=\nshow_page_title=1\npage_title=\nshow_headings=1\nshow_hits=\nitem_show_description=1\nother_cat_show_section=1\nshow_categories=1\nshow_description=1\ndescription_text=\nimage=-1\nimage_align=right\nweblink_icons=\nshow_title=1\n', 0, 0, 0),
(5, 'mainmenu', 'Search', 'search-mainmenu-5', 'index.php?option=com_search', 'component', 0, 26, 15, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=\npageclass_sfx=\nback_button=\nshow_page_title=1\npage_title=\nshow_title=1\n', 0, 0, 0),
(6, 'mainmenu', 'Procesador de texto', 'joomla-license-mainmenu-6', 'index.php?option=com_wrapper&view=wrapper', 'component', 1, 0, 17, 0, 2, 62, '2011-12-19 16:04:58', 0, 0, 1, 0, 'url=http://192.168.152.6/SRA/Calidad/modules/mod_calidad/\nscrolling=auto\nwidth=100%\nheight=720\nheight_auto=0\nadd_scheme=1\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(7, 'mainmenu', 'News Feeds', 'news-feeds-mainmenu-7', 'index.php?option=com_newsfeeds&view=categories', 'component', 0, 26, 11, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\npageclass_sfx=\nback_button=\nshow_page_title=1\npage_title=\nother_cat_show_section=1\nshow_categories=1\ncat_show_description=1\nshow_cat_num_articles=1\nshow_description=1\ndescription_text=\nimage=-1\nimage_align=right\nshow_headings=1\nname=1\narticles=1\nnum_links=0\nfeed_image=1\nfeed_descr=1\nitem_descr=1\nword_count=0\nshow_title=1\n', 0, 0, 0),
(8, 'mainmenu', 'Wrapper', 'wrapper-mainmenu-8', 'index.php?option=com_wrapper&view=wrapper', 'component', 0, 26, 17, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\npageclass_sfx=\nback_button=\nshow_page_title=1\npage_title=\nscrolling=auto\nwidth=100%\nheight=600\nheight_auto=0\nadd=1\nurl=http://www.mozilla.com/en-US/firefox/\nshow_title=1\n', 0, 0, 0),
(9, 'mainmenu', 'Blog', 'blog-mainmenu-9', 'index.php?option=com_content&view=section&layout=blog&id=0', 'component', 0, 23, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\npageclass_sfx=\nback_button=\npage_title=A blog of all sections with no images\nshow_page_title=1\nnum_leading_articles=0\nnum_intro_articles=6\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=\nshow_pagination=2\nshow_pagination_results=1\nimage=0\nshow_description=0\nshow_description_image=0\nshow_category=0\ncategory_num_links=0\nshow_title=1\nlink_titles=\nshow_readmore=\nshow_vote=\nshow_author=\nshow_create_show_date=\nshow_modify_show_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nunpublished=0\nsectionid=0\nshow_title=1\n', 0, 0, 0),
(21, 'usermenu', 'Your Details', 'your-details-usermenu-21', 'index.php?option=com_user&task=edit', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 1, 3, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(13, 'usermenu', 'Submit News', 'submit-news-usermenu-13', 'index.php?option=com_content&task=new&sectionid=1', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 1, 2, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(14, 'usermenu', 'Submit WebLink', 'submit-weblink-usermenu-14', 'index.php?option=com_weblinks&view=weblink&layout=form', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 1, 2, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(15, 'usermenu', 'Check-In My Items', 'check-in-my-items-usermenu-15', 'index.php?option=com_user&task=checkin', 'url', 1, 0, 0, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 1, 2, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(16, 'usermenu', 'Logout', 'logout-usermenu-16', 'index.php?option=com_user&view=login', 'component', 1, 0, 14, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 1, 3, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(17, 'topmenu', 'Home', 'home-topmenu-17', 'index.php', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(18, 'topmenu', 'Contact Us', 'contact-us-topmenu-18', 'index.php?option=com_contact', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(19, 'topmenu', 'News', 'news-topmenu-19', 'index.php?option=com_content&task=section&id=1', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(20, 'topmenu', 'Links', 'links-topmenu-20', 'index.php?option=com_weblinks', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(25, 'mainmenu', 'FAQs', 'faqs-mainmenu-25', 'index.php?option=com_content&view=category&id=7', 'component', 0, 26, 20, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_page_title=1\npageclass_sfx=\nback_button=\nshow_category_description=1\ndescription_cat_image=1\norderby=\ndate_format=\nshow_date=\nshow_author=\nshow_hits=\nshow_headings=1\nshow_item_navigation=1\norder_select=1\nshow_pagination_limit=1\ndisplay_num=50\nfilter=1\nfilter_type=title\nshow_categories=1\nshow_empty_categories=0\nshow_cat_num_articles=1\ncat_show_description=1\nunpublished=1\nshow_title=1\n', 0, 0, 0),
(26, 'mainmenu', 'Joomla Stuff', 'joomla-stuff-mainmenu-26', 'javascript:;', 'url', 0, 0, 0, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=page_white_code_red.png\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(27, 'mainmenu', 'Typography', 'typography-mainmenu-27', 'index.php?option=com_content&view=article&id=12', 'component', 0, 0, 20, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(28, 'mainmenu', 'S5 No-MooMenu', 's5-no-moomenu-mainmenu-28', 'index.php?option=com_content&view=article&id=13', 'component', 0, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=lightning.png\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(29, 'mainmenu', 'Fading Effect Example', 'fading-effect-example-mainmenu-29', 'http://www.shape5.com/demo/duoplate/index.php', 'url', 0, 28, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(30, 'mainmenu', 'Drop In Effect Example', 'drop-in-effect-example-mainmenu-30', 'http://www.shape5.com/demo/duoplate/duoplate2/index.php', 'url', 0, 28, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(31, 'mainmenu', 'Suckerfish Example', 'suckerfish-example-mainmenu-31', 'http://www.shape5.com/demo/duoplate/duoplate3/index.php', 'url', 0, 28, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(32, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-32', 'javascript:;', 'url', 0, 28, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(33, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-33', 'javascript:;', 'url', 0, 32, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(34, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-34', 'javascript:;', 'url', 0, 32, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(35, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-35', 'javascript:;', 'url', 0, 32, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(36, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-36', 'javascript:;', 'url', 0, 35, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(37, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-37', 'javascript:;', 'url', 0, 35, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(38, 'mainmenu', 'Dummy Item', 'dummy-item-mainmenu-38', 'javascript:;', 'url', 0, 35, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(42, 'othermenu', 'Home', 'home-othermenu-42', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(43, 'othermenu', 'Contact Us', 'contact-us-othermenu-43', 'index.php?option=com_contact&view=category', 'component', 1, 0, 7, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(44, 'othermenu', 'Search', 'search-othermenu-44', 'index.php?option=com_search', 'component', 1, 0, 15, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(45, 'othermenu', 'About Us', 'about-us-othermenu-45', 'javascript:;', 'url', 1, 0, 0, 0, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(46, 'othermenu', 'FAQs', 'faqs-othermenu-46', 'index.php?option=com_content&task=category&sectionid=3&id=7', 'url', 1, 0, 0, 0, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(47, 'mainmenu', 'Features', 'features-mainmenu-47', 'javascript:;', 'url', 0, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=database_table.png\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(48, 'mainmenu', 'Tutorials', 'tutorials-mainmenu-48', 'javascript:;', 'url', 0, 0, 0, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=cog_go.png\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(49, 'mainmenu', '22 Module Positions', '22-module-positions-mainmenu-49', 'index.php?option=com_content&view=article&id=14', 'component', 0, 47, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=1\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(52, 'mainmenu', 'NEW! Frontpage Slide Module', 'new-frontpage-slide-module-mainmenu-52', 'index.php?option=com_content&view=article&id=16', 'component', 0, 47, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(53, 'mainmenu', 'Installing The Template', 'installing-the-template-mainmenu-53', 'index.php?option=com_content&view=article&id=17', 'component', 0, 48, 20, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(54, 'mainmenu', 'Configuring The Template', 'configuring-the-template-mainmenu-54', 'index.php?option=com_content&view=article&id=18', 'component', 0, 48, 20, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(55, 'mainmenu', 'LyteBox Setup', 'lytebox-setup-mainmenu-55', 'index.php?option=com_content&view=article&id=19', 'component', 0, 48, 20, 0, 11, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(56, 'mainmenu', 'Setup Module Styles', 'setup-module-styles-mainmenu-56', 'index.php?option=com_content&view=article&id=14', 'component', 0, 48, 20, 0, 12, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(59, 'mainmenu', 'Easy To Follow Steps', 'easy-to-follow-steps-mainmenu-59', 'index.php?option=com_content&view=article&id=22', 'component', 0, 47, 20, 0, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(65, 'mainmenu', 'Custom Page/Column Widths', 'custom-pagecolumn-widths-mainmenu-65', 'index.php?option=com_content&view=article&id=24', 'component', 0, 47, 20, 0, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(68, 'mainmenu', 'NEW! CB Register Module', 'new-cb-register-module-mainmenu-68', 'index.php?option=com_content&view=article&id=27', 'component', 0, 47, 20, 0, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(70, 'mainmenu', 'LyteBox Enabled', 'lytebox-enabled-mainmenu-70', 'index.php?option=com_content&view=article&id=19', 'component', 0, 47, 20, 0, 10, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(92, 'user4', 'Careers', 'careers-user4-92', '#', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(91, 'user4', 'Press', 'press-user4-91', '#', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(90, 'user3', 'International', 'international-user3-90', '#', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(89, 'user3', 'Terms', 'terms-user3-89', '#', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(78, 'mainmenu', 'Three S5 Box''s', 'three-s5-boxs-mainmenu-78', 'index.php?option=com_content&view=article&id=35', 'component', 0, 47, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(79, 'mainmenu', 'Three S5 Box''s', 'three-s5-boxs-mainmenu-79', 'index.php?option=com_content&view=article&id=35', 'component', 0, 48, 20, 0, 13, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(80, 'mainmenu', 'Search Setup', 'search-setup-mainmenu-80', 'index.php?option=com_content&view=article&id=36', 'component', 0, 48, 20, 0, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(88, 'user3', 'Advertise', 'advertise-user3-88', '#', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(87, 'user3', 'Privacy Policy', 'privacy-policy-user3-87', '#', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(83, 'mainmenu', 'NEW! S5 News Ticker', 'new-s5-news-ticker-mainmenu-83', 'index.php?option=com_content&view=article&id=37', 'component', 0, 47, 20, 0, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(84, 'mainmenu', 'Custom Background', 'custom-background-mainmenu-84', 'index.php?option=com_content&view=article&id=30', 'component', 0, 47, 20, 0, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(86, 'mainmenu', 'Tool Tips Enabled', 'tool-tips-enabled-mainmenu-86', 'index.php?option=com_content&view=article&id=38', 'component', 0, 47, 20, 0, 11, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(93, 'user4', 'Blog', 'blog-user4-93', '#', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(94, 'user4', 'Legal Policies', 'legal-policies-user4-94', '#', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(95, 'user5', 'Login', 'login-user5-95', '#', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(96, 'user5', 'Signup', 'signup-user5-96', '#', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(97, 'user5', 'Subscriptions', 'subscriptions-user5-97', '#', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(98, 'user5', 'Newsletters', 'newsletters-user5-98', '#', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(99, 'user6', 'Copyright Notices', 'copyright-notices-user6-99', '#', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(100, 'user6', 'Community Guidelines', 'community-guidelines-user6-100', '#', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(101, 'user6', 'Help & Resources', 'help-a-resources-user6-101', '#', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(102, 'user6', 'More...', 'more-user6-102', '#', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(103, 'user7', 'Home', 'home-user7-103', '#', 'url', 1, 0, 0, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(104, 'user7', 'Contact Us', 'contact-us-user7-104', '#', 'url', 1, 0, 0, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(105, 'user7', 'News', 'news-user7-105', '#', 'url', 1, 0, 0, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(106, 'user7', 'More Links', 'more-links-user7-106', '#', 'url', 1, 0, 0, 0, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(107, 'mainmenu', 'Site Shapers/SQL Dumps', 'site-shaperssql-dumps-mainmenu-107', 'index.php?option=com_content&view=article&id=39', 'component', 0, 48, 20, 0, 14, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(108, 'mainmenu', 'Community Builder', 'community-builder-mainmenu-108', 'index.php?option=com_comprofiler', 'component', 0, 0, 19, 0, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, '\nshow_title=1\nshow_page_title=1\n', 0, 0, 0),
(110, 'mainmenu', 'Logged Out Mode', 'logged-out-mode-mainmenu-110', 'index.php?option=com_content&view=article&id=40', 'component', 0, 47, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'menu_image=-1\nunique_itemid=0\nshow_title=1\nshow_page_title=1\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_menu_types`
--

CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `menutype` varchar(75) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Volcar la base de datos para la tabla `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'mainmenu', ''),
(2, 'othermenu', 'othermenu', ''),
(3, 'topmenu', 'topmenu', ''),
(4, 'user3', 'user3', ''),
(5, 'user4', 'user4', ''),
(6, 'user5', 'user5', ''),
(7, 'user6', 'user6', ''),
(8, 'user7', 'user7', ''),
(9, 'usermenu', 'usermenu', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_messages`
--

CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id_from` int(10) unsigned NOT NULL DEFAULT '0',
  `user_id_to` int(10) unsigned NOT NULL DEFAULT '0',
  `folder_id` int(10) unsigned NOT NULL DEFAULT '0',
  `date_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `state` int(11) NOT NULL DEFAULT '0',
  `priority` int(1) unsigned NOT NULL DEFAULT '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `jos_messages`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_messages_cfg`
--

CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL DEFAULT '0',
  `cfg_name` varchar(100) NOT NULL DEFAULT '',
  `cfg_value` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_messages_cfg`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_migration_backlinks`
--

CREATE TABLE IF NOT EXISTS `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL DEFAULT '',
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_migration_backlinks`
--

INSERT INTO `jos_migration_backlinks` (`itemid`, `name`, `url`, `sefurl`, `newurl`) VALUES
(1, 'Home', 'index.php?option=com_frontpage&Itemid=1', 'index.php?option=com_frontpage&Itemid=1', ''),
(2, 'News', 'index.php?option=com_content&task=section&id=1&Itemid=2', 'index.php?option=com_content&task=section&id=1&Itemid=2', ''),
(3, 'Contact Us', 'index.php?option=com_contact&Itemid=3', 'index.php?option=com_contact&Itemid=3', ''),
(23, 'Links', 'index.php?option=com_weblinks&Itemid=23', 'index.php?option=com_weblinks&Itemid=23', ''),
(5, 'Search', 'index.php?option=com_search&Itemid=5', 'index.php?option=com_search&Itemid=5', ''),
(6, 'Joomla! License', 'index.php?option=com_content&task=view&id=5&Itemid=6', 'index.php?option=com_content&task=view&id=5&Itemid=6', ''),
(7, 'News Feeds', 'index.php?option=com_newsfeeds&Itemid=7', 'index.php?option=com_newsfeeds&Itemid=7', ''),
(8, 'Wrapper', 'index.php?option=com_wrapper&Itemid=8', 'index.php?option=com_wrapper&Itemid=8', ''),
(9, 'Blog', 'index.php?option=com_content&task=blogsection&id=0&Itemid=9', 'index.php?option=com_content&task=blogsection&id=0&Itemid=9', ''),
(10, 'Joomla! Home', 'http://www.joomla.org', 'http://www.joomla.org', ''),
(11, 'Joomla! Forums', 'http://forum.joomla.org', 'http://forum.joomla.org', ''),
(12, 'OSM Home', 'http://www.opensourcematters.org', 'http://www.opensourcematters.org', ''),
(24, 'Administrator', 'administrator/', 'administrator/', ''),
(21, 'Your Details', 'index.php?option=com_user&task=UserDetails&Itemid=21', 'index.php?option=com_user&task=UserDetails&Itemid=21', ''),
(13, 'Submit News', 'index.php?option=com_content&task=new&sectionid=1&Itemid=0', 'index.php?option=com_content&task=new&sectionid=1&Itemid=0', ''),
(14, 'Submit WebLink', 'index.php?option=com_weblinks&task=new&Itemid=14', 'index.php?option=com_weblinks&task=new&Itemid=14', ''),
(15, 'Check-In My Items', 'index.php?option=com_user&task=CheckIn&Itemid=15', 'index.php?option=com_user&task=CheckIn&Itemid=15', ''),
(16, 'Logout', 'index.php?option=com_login&Itemid=16', 'index.php?option=com_login&Itemid=16', ''),
(17, 'Home', 'index.php', 'index.php', ''),
(18, 'Contact Us', 'index.php?option=com_contact&Itemid=3', 'index.php?option=com_contact&Itemid=3', ''),
(19, 'News', 'index.php?option=com_content&task=section&id=1&Itemid=2', 'index.php?option=com_content&task=section&id=1&Itemid=2', ''),
(20, 'Links', 'index.php?option=com_weblinks&Itemid=23', 'index.php?option=com_weblinks&Itemid=23', ''),
(25, 'FAQs', 'index.php?option=com_content&task=category&sectionid=3&id=7&Itemid=25', 'index.php?option=com_content&task=category&sectionid=3&id=7&Itemid=25', ''),
(26, 'Joomla Stuff', 'javascript:;', 'javascript:;', ''),
(27, 'Typography', 'index.php?option=com_content&task=view&id=12&Itemid=27', 'index.php?option=com_content&task=view&id=12&Itemid=27', ''),
(28, 'S5 No-MooMenu', 'index.php?option=com_content&task=view&id=13&Itemid=28', 'index.php?option=com_content&task=view&id=13&Itemid=28', ''),
(29, 'Fading Effect Example', 'http://www.shape5.com/demo/duoplate/index.php', 'http://www.shape5.com/demo/duoplate/index.php', ''),
(30, 'Drop In Effect Example', 'http://www.shape5.com/demo/duoplate/duoplate2/index.php', 'http://www.shape5.com/demo/duoplate/duoplate2/index.php', ''),
(31, 'Suckerfish Example', 'http://www.shape5.com/demo/duoplate/duoplate3/index.php', 'http://www.shape5.com/demo/duoplate/duoplate3/index.php', ''),
(32, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(33, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(34, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(35, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(36, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(37, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(38, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(39, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(40, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(41, 'Dummy Item', 'javascript:;', 'javascript:;', ''),
(42, 'Home', 'index.php?option=com_frontpage&Itemid=42', 'index.php?option=com_frontpage&Itemid=42', ''),
(43, 'Contact Us', 'index.php?option=com_contact&Itemid=43', 'index.php?option=com_contact&Itemid=43', ''),
(44, 'Search', 'index.php?option=com_search&Itemid=44', 'index.php?option=com_search&Itemid=44', ''),
(45, 'About Us', 'javascript:;', 'javascript:;', ''),
(46, 'FAQs', 'index.php?option=com_content&task=category&sectionid=3&id=7&Itemid=25', 'index.php?option=com_content&task=category&sectionid=3&id=7&Itemid=25', ''),
(47, 'Features', 'javascript:;', 'javascript:;', ''),
(48, 'Tutorials', 'javascript:;', 'javascript:;', ''),
(49, '22 Module Positions', 'index.php?option=com_content&task=view&id=14&Itemid=49', 'index.php?option=com_content&task=view&id=14&Itemid=49', ''),
(50, '42 Module Styles', 'index.php?option=com_content&task=view&id=14&Itemid=50', 'index.php?option=com_content&task=view&id=14&Itemid=50', ''),
(51, '30 Preset Styles or Custom!', 'index.php?option=com_content&task=view&id=15&Itemid=51', 'index.php?option=com_content&task=view&id=15&Itemid=51', ''),
(52, 'NEW! Frontpage Slide Module', 'index.php?option=com_content&task=view&id=16&Itemid=52', 'index.php?option=com_content&task=view&id=16&Itemid=52', ''),
(53, 'Installing The Template', 'index.php?option=com_content&task=view&id=17&Itemid=53', 'index.php?option=com_content&task=view&id=17&Itemid=53', ''),
(54, 'Configuring The Template', 'index.php?option=com_content&task=view&id=18&Itemid=54', 'index.php?option=com_content&task=view&id=18&Itemid=54', ''),
(55, 'LyteBox Setup', 'index.php?option=com_content&task=view&id=19&Itemid=55', 'index.php?option=com_content&task=view&id=19&Itemid=55', ''),
(56, 'Setup Module Styles', 'index.php?option=com_content&task=view&id=14&Itemid=56', 'index.php?option=com_content&task=view&id=14&Itemid=56', ''),
(57, 'Search & Bottom Menu Setup', 'index.php?option=com_content&task=view&id=20&Itemid=57', 'index.php?option=com_content&task=view&id=20&Itemid=57', ''),
(58, 'Column Menu Setup', 'index.php?option=com_content&task=view&id=21&Itemid=58', 'index.php?option=com_content&task=view&id=21&Itemid=58', ''),
(59, 'Easy To Follow Steps', 'index.php?option=com_content&task=view&id=22&Itemid=59', 'index.php?option=com_content&task=view&id=22&Itemid=59', ''),
(60, 'S5 No-MooMenu', 'index.php?option=com_content&task=view&id=13&Itemid=60', 'index.php?option=com_content&task=view&id=13&Itemid=60', ''),
(61, 'Horizontal Login Module', 'index.php?option=com_content&task=view&id=23&Itemid=61', 'index.php?option=com_content&task=view&id=23&Itemid=61', ''),
(62, 'Horizontal Login Module', 'index.php?option=com_content&task=view&id=23&Itemid=62', 'index.php?option=com_content&task=view&id=23&Itemid=62', ''),
(63, 'Create a Custom Color Style', 'index.php?option=com_content&task=view&id=15&Itemid=63', 'index.php?option=com_content&task=view&id=15&Itemid=63', ''),
(64, 'S5 Tab Show Setup', 'index.php?option=com_content&task=view&id=16&Itemid=64', 'index.php?option=com_content&task=view&id=16&Itemid=64', ''),
(65, 'Custom Page/Column Widths', 'index.php?option=com_content&task=view&id=24&Itemid=65', 'index.php?option=com_content&task=view&id=24&Itemid=65', ''),
(66, 'Two Logo Options', 'index.php?option=com_content&task=view&id=25&Itemid=66', 'index.php?option=com_content&task=view&id=25&Itemid=66', ''),
(67, 'S5 Ultimate Drop Down', 'index.php?option=com_content&task=view&id=26&Itemid=67', 'index.php?option=com_content&task=view&id=26&Itemid=67', ''),
(68, 'NEW! CB Register Module', 'index.php?option=com_content&task=view&id=27&Itemid=68', 'index.php?option=com_content&task=view&id=27&Itemid=68', ''),
(69, 'No Script Conflictions!', 'index.php?option=com_content&task=view&id=28&Itemid=69', 'index.php?option=com_content&task=view&id=28&Itemid=69', ''),
(70, 'LyteBox Enabled', 'index.php?option=com_content&task=view&id=19&Itemid=70', 'index.php?option=com_content&task=view&id=19&Itemid=70', ''),
(71, 'Create Your Own Background', 'index.php?option=com_content&task=view&id=30&Itemid=71', 'index.php?option=com_content&task=view&id=30&Itemid=71', ''),
(72, 'NEW! - S5 Frontpage Display', 'index.php?option=com_content&task=view&id=31&Itemid=72', 'index.php?option=com_content&task=view&id=31&Itemid=72', ''),
(92, 'Careers', '#', '#', ''),
(91, 'Press', '#', '#', ''),
(90, 'International', '#', '#', ''),
(89, 'Terms', '#', '#', ''),
(77, 'Logo and Custom Background', 'index.php?option=com_content&task=view&id=30&Itemid=77', 'index.php?option=com_content&task=view&id=30&Itemid=77', ''),
(78, 'Three S5 Box''s', 'index.php?option=com_content&task=view&id=35&Itemid=78', 'index.php?option=com_content&task=view&id=35&Itemid=78', ''),
(79, 'Three S5 Box''s', 'index.php?option=com_content&task=view&id=35&Itemid=79', 'index.php?option=com_content&task=view&id=35&Itemid=79', ''),
(80, 'Search Setup', 'index.php?option=com_content&task=view&id=36&Itemid=80', 'index.php?option=com_content&task=view&id=36&Itemid=80', ''),
(88, 'Advertise', '#', '#', ''),
(87, 'Privacy Policy', '#', '#', ''),
(83, 'NEW! S5 News Ticker', 'index.php?option=com_content&task=view&id=37&Itemid=83', 'index.php?option=com_content&task=view&id=37&Itemid=83', ''),
(84, 'Custom Background', 'index.php?option=com_content&task=view&id=30&Itemid=84', 'index.php?option=com_content&task=view&id=30&Itemid=84', ''),
(85, 'S5 Horizontal Slide', 'index.php?option=com_content&task=view&id=27&Itemid=85', 'index.php?option=com_content&task=view&id=27&Itemid=85', ''),
(86, 'Tool Tips Enabled', 'index.php?option=com_content&task=view&id=38&Itemid=86', 'index.php?option=com_content&task=view&id=38&Itemid=86', ''),
(93, 'Blog', '#', '#', ''),
(94, 'Legal Policies', '#', '#', ''),
(95, 'Login', '#', '#', ''),
(96, 'Signup', '#', '#', ''),
(97, 'Subscriptions', '#', '#', ''),
(98, 'Newsletters', '#', '#', ''),
(99, 'Copyright Notices', '#', '#', ''),
(100, 'Community Guidelines', '#', '#', ''),
(101, 'Help & Resources', '#', '#', ''),
(102, 'More...', '#', '#', ''),
(103, 'Home', '#', '#', ''),
(104, 'Contact Us', '#', '#', ''),
(105, 'News', '#', '#', ''),
(106, 'More Links', '#', '#', ''),
(107, 'Site Shapers/SQL Dumps', 'index.php?option=com_content&task=view&id=39&Itemid=107', 'index.php?option=com_content&task=view&id=39&Itemid=107', ''),
(108, 'Community Builder', 'index.php?option=com_comprofiler&Itemid=108', 'index.php?option=com_comprofiler&Itemid=108', ''),
(109, 'Logged Out Mode', 'index.php?option=com_content&task=view&id=41&Itemid=109', 'index.php?option=com_content&task=view&id=41&Itemid=109', ''),
(110, 'Logged Out Mode', 'index.php?option=com_content&task=view&id=40&Itemid=110', 'index.php?option=com_content&task=view&id=40&Itemid=110', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_migration_configuration`
--

CREATE TABLE IF NOT EXISTS `jos_migration_configuration` (
  `cid` int(12) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL DEFAULT '',
  `value` text,
  PRIMARY KEY (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Volcar la base de datos para la tabla `jos_migration_configuration`
--

INSERT INTO `jos_migration_configuration` (`cid`, `key`, `value`) VALUES
(1, 'offline_message', 'This site is down for maintenance.<br /> Please check back again soon.'),
(2, 'sitename', 'CommPortal'),
(3, 'debug', '0'),
(4, 'MetaDesc', 'Joomla - the dynamic portal engine and content management system'),
(5, 'MetaKeys', 'Joomla, joomla'),
(6, 'MetaTitle', '1'),
(7, 'MetaAuthor', '1'),
(8, 'gzip', '0'),
(9, 'editor', 'none'),
(10, 'smtpauth', '0'),
(11, 'smtpuser', ''),
(12, 'smtppass', ''),
(13, 'smtphost', 'localhost'),
(14, 'sendmail', '/usr/sbin/sendmail'),
(15, 'fromname', 'CommPortal'),
(16, 'mailfrom', 'admin@admin.com'),
(17, 'mailer', 'mail'),
(18, 'caching', '0'),
(19, 'error_reporting', '-1'),
(20, 'list_limit', '30');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_modules`
--

CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL DEFAULT '0',
  `position` varchar(50) DEFAULT NULL,
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `module` varchar(50) DEFAULT NULL,
  `numnews` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `showtitle` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  `control` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=90 ;

--
-- Volcar la base de datos para la tabla `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu', '', 0, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx=_menu\nmaxdepth=10\nmenu_images=1\nmenu_images_align=0\nmenu_images_link=1\nexpand_menu=1\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'Encuesta', '', 2, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_poll', 0, 0, 0, 'id=14\nmoduleclass_sfx=\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(17, 'User Menu', '', 2, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 1, 1, 'menutype=usermenu', 1, 0, ''),
(18, 'Main Menu', '', 0, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 0, 'menutype=mainmenu\nmenu_style=vert_indent\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=1\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=con_address.png\nindent_image2=con_fax.png\nindent_image3=con_fax.png\nindent_image4=indent4.png\nindent_image5=con_info.png\nindent_image6=indent.png\nspacer=\nend_spacer=\n\n', 1, 0, ''),
(19, 'Login Form', '', 0, 'cpanel', 0, '0000-00-00 00:00:00', 0, 'mod_login', 0, 0, 1, 'cache=0\nmoduleclass_sfx=\npretext=\nposttext=\nlogin=\nlogout=\ngreeting=1\nname=0\nusesecure=0\n\n', 1, 0, ''),
(20, 'Articles of Interest', '', 0, 'advert4', 0, '0000-00-00 00:00:00', 0, 'mod_latestnews', 0, 0, 1, 'count=13\nordering=c_dsc\nuser_id=0\nshow_front=1\nsecid=1\ncatid=1\nmoduleclass_sfx=\ncache=0\ncache_time=900\n\n', 1, 0, ''),
(21, 'Who''s Online', '', 1, 's5_fs_7', 0, '0000-00-00 00:00:00', 0, 'mod_whosonline', 0, 0, 1, 'showmode=0\nmoduleclass_sfx=', 0, 0, ''),
(22, 'Popular Items', '', 1, 'user9', 0, '0000-00-00 00:00:00', 1, 'mod_mostread', 0, 0, 1, 'moduleclass_sfx=\ncache=0\ntype=1\nshow_front=1\ncount=5\ncatid=\nsecid=', 0, 0, ''),
(23, 'Archive', '', 4, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_archive', 0, 0, 1, '', 1, 0, ''),
(24, 'Sections', '', 1, 'user8', 0, '0000-00-00 00:00:00', 0, 'mod_sections', 0, 0, 1, 'count=5\nmoduleclass_sfx=', 1, 0, ''),
(25, 'S5 Boxes', '  <br /><br />  <div style="width: 220px; float: left"> <img src="images/s5boxes.jpg" alt="S5 Effects" /> </div>  <div style="font-weight: normal; color: #6b6b6b; width: 166px; float: left"><h3 style="font-weight: normal; font-size: 18px; color: #6b6b6b">3 S5 Box&#39;s</h3>\r\nChoose from 3 S5 Box''s, drop down, register (option to hide on login) and login (text can change on login).  Text for all 3 can be changed via template manager J1.5 and index.php J1.0.\r\n\r\n\r\n<br/> <a class="readon" href="index.php?option=com_content&amp;task=view&amp;id=29&amp;Itemid=1">\r\n							Read more...</a> </div>  ', 1, 's5_fs_4', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(26, 'Related Items', '', 5, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_related_items', 0, 0, 1, '', 0, 0, ''),
(27, 'Search', '', 1, 'top', 0, '0000-00-00 00:00:00', 1, 'mod_search', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nset_itemid=\nwidth=20\ntext=\nbutton=\nbutton_pos=right\nbutton_text=', 0, 0, ''),
(28, 'Random Image', '', 4, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_random_image', 0, 0, 0, 'type=jpg\nfolder=\nlink=\nwidth=\nheight=\nmoduleclass_sfx=\ncache=0\ncache_time=900\n\n', 0, 0, ''),
(29, 'Top Menu', '', 1, 'user3', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 0, 'menutype=topmenu\nmenu_style=list_flat\nmenu_images=n\nmenu_images_align=left\nexpand_menu=n\nclass_sfx=-nav\nmoduleclass_sfx=\nindent_image1=0\nindent_image2=0\nindent_image3=0\nindent_image4=0\nindent_image5=0\nindent_image6=0', 1, 0, ''),
(30, 'Banners', '', 0, 'banner', 0, '0000-00-00 00:00:00', 1, 'mod_banners', 0, 0, 0, 'target=1\ncount=1\ncid=0\ncatid=0\ntag_search=0\nordering=0\nheader_text=\nfooter_text=\nmoduleclass_sfx=\ncache=1\ncache_time=900\n\n', 1, 0, ''),
(31, 'Other Menu', '', 1, 'bottom', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 0, 'class_sfx=-bottom\nmoduleclass_sfx=\nmenutype=othermenu\nmenu_style=list_flat\nfull_active_id=0\ncache=0\nmenu_images=0\nmenu_images_align=0\nexpand_menu=0\nactivate_parent=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=', 0, 0, ''),
(32, 'Wrapper', '', 1, 'newsflash', 0, '0000-00-00 00:00:00', 0, 'mod_wrapper', 0, 0, 1, 'moduleclass_sfx=\nurl=\nscrolling=auto\nwidth=100%\nheight=200\nheight_auto=1\nadd=1', 0, 0, ''),
(33, 'Quote From a Member', '&quot;Shape5 is definitely a worthwhile investment for any amateur such as myself.\r\n\r\nThere is so much info in the forums, that I didn''t have to come in and ask any questions -- I found what I needed right here in the forums.\r\n\r\nShape5 = professional template + professional documentation +  professional support .&quot;<br />', 1, 'user4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(34, 'advert3', 'This is the advert3 position.', 1, 'advert3', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(35, 'left', 'This is the left position ', 1, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(36, 'banner', '<p>This is the banner position</p>', 2, 'banner', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(37, 'ticker1', 'This is the ticker1 position ', 1, 'ticker1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(38, 'user1', 'This is the default module style', 3, 'user1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(39, 'user2', 'This is the default module style', 2, 'user2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(40, 'user3', 'user3 position', 3, 'user3', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(41, 'user4', 'user4 position', 3, 'user4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(42, 'user5', 'user5 position', 1, 'user5', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-dark\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(43, 'user6', 'user6 position', 1, 'user6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-dark\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(44, 'advert2', 'This is the advert2 position.', 2, 'advert2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(45, 'user9', 'user9 position', 3, 'user9', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(46, 'advert4', 'This is the advert4 position. ', 2, 'advert4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(47, 'Site Shapers Available', '<span style="color:#6B6B6B;">So what are Site Shapers?  They are quick installs of Joomla combined with all the modules, images, etc used on our demo.  Within a few minutes you can have your site up, running and looking just like our demo.  No more importing SQL dumps and installing modules.  \r\n<br/>\r\n<br/>\r\nBoth Joomla 1.0.x and Joomla 1.5 Site Shapers are available.</span>', 1, 's5_fs_6', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(48, 'Top', '<br/>top module position', 2, 'top', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(49, 'S5 Frontpage Slider', '<span style="color:#6B6B6B;"><strong>1.</strong> Choose Mootools slide in or S5 Effects snap in or fade in effects (Choose S5 Effects to guarantee no script conflictions)\r\n<br/><strong>2.</strong> Set button backgrounds and hovers\r\n<br/><strong>3.</strong> Position buttons to the left or right of the sliding modules\r\n<br/><strong>4.</strong> Holds up to 10 module positions\r\n<br/><strong>5.</strong> Enable/Disable shadows\r\n<br/><strong>6.</strong> Specify the width and height of the module\r\n<br/><strong>7.</strong> XHTML Valid</span>\r\n\r\n<br/><br/>\r\n<a style="float:left;" href="index.php?option=com_content&amp;task=view&amp;id=16&amp;Itemid=52" class="readon">\r\n							Read more...</a>', 1, 's5_fs_3', 62, '2011-11-29 14:34:47', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(50, 'advert5', 'This is the advert5 position. ', 1, 'advert5', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(51, 'ticker2', '<p>This is the ticker2 position</p>', 0, 'ticker2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(52, 'advert6', 'This is the advert6 position.', 1, 'advert6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(53, 'user7', 'user7 position', 2, 'user7', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(54, 'user8', 'user8 position', 3, 'user8', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(55, 'advert1', 'This is the advert1 position.', 2, 'advert1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(56, 'S5 CB Register', '<a href="index.php?option=com_content&task=view&id=27&Itemid=68"><img src="images/regmodule.jpg" border="0" alt="S5 CB Register" /></a>', 2, 'advert6', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(57, 'World Class Service!', 'Shape 5 has built a great reputation for good customer service! \r\n<br /><br/>Take some time to read what our members \r\nare saying about Shape 5...\r\n<a target="_top" href="http://www.shape5.com/component/option,com_smf/Itemid,75/board,17.0">\r\nclick here</a>!', 3, 'user6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(58, 'Información extra', '<p><img src="images/stories/articles.jpg" border="0" /></p>', 0, 'toolbar', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(82, 'Auditoría de la Información.', '<h1><strong><a href="index.php?option=com_content&amp;view=article&amp;id=43&amp;Itemid=6" style="background: url(images/application_go.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Auditoría de la Información.</a></strong><strong><span style="font-family: Arial;" lang="ES"> </span></strong><strong><span style="font-family: Arial;" lang="ES"> <br /></span></strong></h1>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Detectar las posibles irregularidades en las operaciones que realizan los Centros Informantes.</span></li>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Verificar la Calidad del Dato en la Información Estadísticas.</span></li>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Informar los Resultados de las Auditorías Realizadas.</span></li>\r\n</ul>\r\n<p class="Prrafodelista" style="text-align: justify; text-indent: -18pt;"><span style="font-family: Arial;" lang="ES"><span> </span></span><span style="font-family: Arial;" lang="ES"> </span></p>\r\n<p class="MsoNormal" style="margin-left: 36pt; text-align: justify; text-indent: -18pt;"> </p>', 2, 's5_fs_3', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(59, 'S5 Box 2 - debug position', 'This is the S5 Box 2 with a module position of "login".  The "login" text can be changed via the index.php file in J1.0 or the template manager in J1.5.  "logout" text can also be added for this position.  When a user is logged in the button text will change to "logout".\r\n<Br/><br/>\r\nFeatures:\r\n<br/>\r\n<br/>-Specify width (via index.php file in J1.0 or the template manager in J1.5)\r\n<br/>-Height automatically adjusts to content.\r\n<br/>-Change button text\r\n<br/>-Choose text to show for button when user is logged in\r\n\r\n<Br/><br/>\r\nNOTE: This position and the "login" button will not show unless a module is published to the debug position. \r\n<Br/><br/>\r\n\r\nBest of all, the three S5 Box''s are powered by S5 Effects so this means no script conflictions!', 1, 'debug', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(60, 'Script Conflictions?', '  <br /><br />  <div style="width: 178px; float: left"> <img src="images/s5effects.jpg" alt="S5 Effects" /> </div>  <div style="font-weight: normal; color: #6b6b6b; width: 200px; float: left"><h3 style="font-weight: normal; font-size: 18px; color: #6b6b6b">Powered by S5 Effects<br /></h3>Having trouble with modules and or components conflicting with your template? CommPortal is completely powered by S5 Effects. This means you are guaranteed to experience no script conflictions with any modules or components you may be using on your website. </div>  ', 1, 's5_fs_2', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(61, 'right', 'This is the right position', 3, 'right', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\n\n', 0, 0, ''),
(62, 'bottom menu', 'bottom position, use menu suffix "-bottom"', 2, 'bottom', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 0, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(63, 'Two Template Themes', 'Duoplate comes with two different template themes, a Church and a Band theme:\r\n<br/>\r\n<br/>\r\n\r\n\r\n\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.shape5.com/demo/duoplate/index.php"><img src="http://www.shape5.com/demo/duoplate/images/church.jpg" alt="Church Demo" border="0"/></a>\r\n\r\n<br/>\r\n<br/>\r\n\r\n\r\n\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://www.shape5.com/demo/duoplate/duoplate2/index.php"><img src="http://www.shape5.com/demo/duoplate/images/band.jpg" alt="Band Demo" border="0"/></a>', 2, 'slider6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=-opacity\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(64, 'S5 Box 1 - cpanel position', 'This is the S5 Box 1 with a module position of "cpanel".  The "register" text can be changed via the index.php file in J1.0 or the template manager in J1.5.  You can also specify to either show or hide this button if a user is logged in.  So if you want to use a registration module (like the CB one we provide) and then when a user is logged in have this button disappear the S5 Box 1 position allows you to do so (this is enabled by default).\r\n<Br/><br/>\r\nFeatures:\r\n<br/>\r\n<br/>-Specify width (via index.php file in J1.0 or the template manager in J1.5)\r\n<br/>-Height automatically adjusts to content.\r\n<br/>-Change button text\r\n<br/>-Choose to hide module button and position when a user is logged in\r\n\r\n<Br/><br/>\r\nNOTE: This position and the "login" button will not show unless a module is published to the debug position. \r\n<Br/><br/>\r\n\r\nBest of all, the three S5 Box''s are powered by S5 Effects so this means no script conflictions!', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(65, 'Company Info', '', 2, 'user3', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=user3\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=0\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(66, 'Member Quote', 'I am so glad I went with Shape5 from the beginning. Shape5 is definitely at the top of the food chain when it comes to Template Clubs! <br /><br />Thank you Shape5 for high-end quality products and the Unsurpassed support,<br />Tom Stepanski Jr.', 2, 'advert5', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(67, 'Logged Out Mode', 'CommPortal includes an option to enable a "logged out mode" of the template.  This limits what a user can view if he/she is not registered and logged in.  This is useful if you want to keep the bandwidth on your site to a minimum and force user registration to view your entire site.\r\n<br/><br/>\r\n<div class="blue_box">If using this method of template functionality you will have to sure the CB Regsiter or similar module to allow user registration as the Joomla main body area (where registration components output their text) is not accessible. </div>', 2, 'user8', 62, '2008-07-15 14:08:41', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(68, 'More Links', '', 0, 'user7', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=user7\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=4\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(69, 'Useful Links', '', 2, 'user4', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=user4\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=1\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(70, 'Community', '', 2, 'user5', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=user5\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=2\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(71, 'Links', '', 2, 'user6', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=user6\nmenu_style=list_flat\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=0\ntag_id=\nclass_sfx=3\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\nend_spacer=\n\n', 0, 0, ''),
(72, 'Logged Out Mode', '<span style="color:#6B6B6B;">This month we introduce for the first time in the Joomla template community an option to enabled a logged out mode.  The logged out mode will only show the homepage with a few modules.  All other pages that a user tries to navigate to will throw up a message asking them to register or login via the homepage.  This option can be enabled or disabled via the template configuration.</span>\r\n\r\n<br/><br/>\r\n<a class="readon" href="#">\r\n							Read more...</a>', 1, 's5_fs_5', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\ncache=0\nfirebots=1\nrssurl=\nrsstitle=1\nrssdesc=1\nrssimage=1\nrssitems=3\nrssitemdesc=1\nword_count=0\nrsscache=3600', 0, 0, ''),
(73, 'Breadcrumbs', '', 0, 'breadcrumb', 0, '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 0, 0, 0, 'showHome=1\nhomeText=Inicio\nshowLast=1\nseparator=\nmoduleclass_sfx=\ncache=0\n\n', 1, 0, ''),
(74, 'Flahs de notcicias', '', 0, 'ticker2', 0, '0000-00-00 00:00:00', 1, 'mod_s5_newsticker', 0, 0, 0, 'pretext=\nmoduleclass_sfx=\ntween_time=0.50\ndisplay_time=4\nheight=45px\nwidth=100%\ntext1line=<b>Pensar en positivo es calidad!</b>\ntext2line=<b>Ser educado es calidad!\ntext3line=<b>Ser organizado es calidad!\ntext4line=<b>Ser prevenido es calidad!\ntext5line=Ser atento es calidad!\ntext6line=<b>Respetar la salud es calidad!\ntext7line=<b>Cumplir lo planificado es calidad!\ntext8line=<b>Tener paciencia es calidad!\ntext9line=<b>Decir la verdad es calidad!\ntext10line=<b>Amar a la familia y a sus amigos es la mayor calidad!\n\n', 0, 0, ''),
(75, 'Panel Principal', '', 0, 'user1', 0, '0000-00-00 00:00:00', 1, 'mod_s5_frontpageslide', 0, 0, 0, 'pretext=\nmoduleclass_sfx=\ns5_buttoncolumnwidth=320px\ns5_width=930px\ns5_height=300px\ns5_buttonheight=30px\ns5_lineheight=2.2em\ns5_buttoncolor=transparent\ns5_buttonimage=modules/mod_s5_frontpageslide/s5_frontpageslide/repeatback.jpg\ns5_hovercolor=#FFFFFF\ns5_hoverimage=modules/mod_s5_frontpageslide/s5_frontpageslide/arrow.jpg\ns5_fontcolor=#000000\ns5_shadows=1\ns5_aligncolumn=left\ns5_javascript=mootools\ns5_mootoolsmouse=click\ns5_effectsani=fade\ns5_effectmouse=mouse\ntext1line=Informacion General\ntext1image=images/group.jpg\ntext2line=Administrativo.\ntext2image=images/s5logo.jpg\ntext3line=Auditoría de la Información.\ntext3image=images/application_go.jpg\ntext4line=Captación y Procesamiento de la Información.\ntext4image=images/application_double.jpg\ntext5line=Demografía y Estadísticas Sociales.\ntext5image=images/lock.jpg\ntext6line=Gestión de la Información.\ntext6image=images/compress.jpg\ntext7line=Gestión del Capital Humano.\ntext7image=images/group.jpg\ntext8line=Sistema Informático.\ntext8image=images/application_go.jpg\ntext9line=\ntext9image=\ntext10line=\ntext10image=\n\n', 0, 0, ''),
(76, 'S5 Frontpage Slide - Fade-In Demo (S5 Effects)', '', 2, 'bottom', 0, '0000-00-00 00:00:00', 1, 'mod_s5_frontpageslide', 0, 0, 1, 'pretext=\nmoduleclass_sfx=\ns5_buttoncolumnwidth=200px\ns5_width=660px\ns5_height=230px\ns5_buttonheight=30px\ns5_lineheight=2.2em\ns5_buttoncolor=transparent\ns5_buttonimage=modules/mod_s5_frontpageslide/s5_frontpageslide/repeatback.jpg\ns5_hovercolor=#FFFFFF\ns5_hoverimage=modules/mod_s5_frontpageslide/s5_frontpageslide/arrow.jpg\ns5_fontcolor=#000000\ns5_shadows=1\ns5_aligncolumn=left\ns5_javascript=s5effects\ns5_mootoolsmouse=mouse\ns5_effectsani=fade\ns5_effectmouse=mouse\ntext1line=Latest Users\ntext1image=images/group.jpg\ntext2line=S5 Effects Powered\ntext2image=images/s5logo.jpg\ntext3line=S5 Frontpage Slider\ntext3image=images/application_go.jpg\ntext4line=S5 Box''s\ntext4image=images/application_double.jpg\ntext5line=Template logged out\ntext5image=images/lock.jpg\ntext6line=Site Shaper (demo zips)\ntext6image=images/compress.jpg\ntext7line=Who''s Online\ntext7image=images/status_online.jpg\ntext8line=\ntext8image=\ntext9line=\ntext9image=\ntext10line=\ntext10image=\n\n', 0, 0, ''),
(77, 'S5 News Ticker - Demo', '', 2, 'user9', 0, '0000-00-00 00:00:00', 1, 'mod_s5_newsticker', 0, 0, 1, 'pretext=\nmoduleclass_sfx=\ntween_time=0.75\ndisplay_time=4\nheight=45px\nwidth=100%\ntext1line=S5 Text Fader, Author: http://www.shape5.com\ntext2line=Shape 5 provides professional, script confliction free templates\ntext3line=\ntext4line=\ntext5line=\ntext6line=\ntext7line=\ntext8line=\ntext9line=\ntext10line=\n\n', 0, 0, ''),
(78, 'Registrate', '', 0, 'cpanel', 0, '0000-00-00 00:00:00', 0, 'mod_cb_s5register', 0, 0, 0, 'moduleclass_sfx=\npretext=\nposttext=\nterms=2\ntermslink=\nimages=1\n\n', 0, 0, ''),
(79, 'Entra como Usuario', '', 0, 'debug', 0, '0000-00-00 00:00:00', 1, 'mod_cblogin', 0, 0, 1, 'moduleclass_sfx=\nhorizontal=0\ncompact=0\npretext=\nposttext=\nlogin=\nlogout=index.php\nshow_lostpass=0\nshow_newaccount=0\nname_lenght=10\npass_lenght=10\nlogin_message=0\nlogout_message=0\nremember_enabled=1\ngreeting=1\nname=0\nshow_avatar=0\navatar_position=default\npms_type=0\nshow_pms=0\nshow_connection_notifications=0\nhttps_post=0\n\n', 0, 0, ''),
(80, 'CB Usuarios', '', 0, 's5_fs_1', 0, '0000-00-00 00:00:00', 0, 'mod_cb_superthumb', 0, 0, 0, 'count=10\nwidth_thumbcb=60\nheight_thumbcb=60\niditemuse=0\niditem=68\nmodulename=2\nshownotavatar=1\nshownamedetails=1\nviewname=0\nshowimagenot=1\nviewgroup=1\nimagelinked=1\nuserlinked=1\ntoolbar=0\nwidth=15\nheight=15\nsendpm=1\npmssystem=mesjim\nsendmail=0\nconects=1\nprofilelink=0\ngrouplink=1\nmoduleclass_sfx=\n\n', 0, 0, ''),
(81, 'Administrativo', '<h1><strong><a href="index.php?option=com_content&amp;view=article&amp;id=41&amp;Itemid=6" style="background: url(images/s5logo.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Administrativo.</a></strong></h1>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<p class="MsoNormal" style="margin-left: 36pt; text-align: justify; text-indent: -18pt;"><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Garantizar el Aseguramiento del Transporte, limpieza e higiene de los locales, la compra de insumos y materiales, el mantenimiento del equipamiento necesario para el funcionamiento de la organización.</span></p>\r\n<p class="MsoNormal" style="margin-left: 36pt; text-align: justify; text-indent: -18pt;"><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Garantizar el control adecuado del presupuesto asignado para proveer los recursos financieros requeridos para el funcionamiento de la organización y garantizar el fondo de salarios. </span></p>', 2, 's5_fs_2', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(83, 'Captación y Procesamiento de la Información.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=44&amp;Itemid=6" style="background: url(images/application_double.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Captación y Procesamiento de la Información.</a></h1>\r\n<p> </p>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<p class="Prrafodelista" style="text-align: justify; text-indent: -18pt;"><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Captar y procesar el 100 % de la información en las fechas establecidas a partir del convenio con los centros informantes.</span></li>\r\n</ul>\r\n<p class="Prrafodelista" style="text-align: justify; text-indent: -18pt;"><span style="font-family: Arial;" lang="ES"> </span></p>', 2, 's5_fs_4', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(84, 'Demografía y Estadísticas Sociales.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=45&amp;Itemid=6" style="background: url(images/lock.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Demografía y Estadísticas Sociales.</a></h1>\r\n<p> </p>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if !mso]> \r\n<object  classid="clsid:38481807-CA0E-42D2-BF39-B33AF135CC4D" id=ieooui>\r\n</object>\r\n<mce:style><!  st1\\:*{behavior:url(#ieooui) } --> <!--[endif] --><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-family: Arial;" lang="ES"> </span></p>\r\n<p class="MsoNormal" style="text-align: justify;"><strong><span style="font-family: Arial;" lang="ES"> </span></strong></p>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Captar las estadísticas vitales de la población, indicadores sociales y encuestas orientadas por la  Dirección Nacional de Estadísticas.</span></li>\r\n</ul>', 2, 's5_fs_5', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(85, 'Gestión de la Información.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=46&amp;Itemid=6" style="background: url(images/compress.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión de la Información.</a></h1>\r\n<p> </p>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-family: Arial;" lang="ES"> </span></p>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES-MX">Difundir el 100 % de la información existente en la entidad solicitada por los organismos.</span></li>\r\n</ul>', 2, 's5_fs_6', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(86, 'Gestión de la Dirección para la Mejora Continua.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=47&amp;Itemid=6" style="background: url(images/status_online.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión de la Dirección para la Mejora Continua.</a></h1>', 2, 's5_fs_7', 0, '0000-00-00 00:00:00', 0, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(87, 'Gestión del Capital Humano.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=48&amp;Itemid=6" style="background: url(images/group.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Gestión del Capital Humano.</a></h1>\r\n<p> </p>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;">Atraer, retener, desarrollar y proteger permanentemente a sus trabajadores, así como incrementar sus competencias para el logro de los objetivos estratégicos.</span><strong> </strong></li>\r\n</ul>', 0, 's5_fs_7', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(88, 'Sistema Informático.', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=49&amp;Itemid=6" style="background: url(images/application_go.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Sistema Informático.</a></h1>\r\n<p> </p>\r\n<p><!--[if gte mso 9]><xml> <w:WordDocument> <w:View>Normal</w:View> <w:Zoom>0</w:Zoom> <w:HyphenationZone>21</w:HyphenationZone> <w:PunctuationKerning /> <w:ValidateAgainstSchemas /> <w:SaveIfXMLInvalid>false</w:SaveIfXMLInvalid> <w:IgnoreMixedContent>false</w:IgnoreMixedContent> <w:AlwaysShowPlaceholderText>false</w:AlwaysShowPlaceholderText> <w:Compatibility> <w:BreakWrappedTables /> <w:SnapToGridInCell /> <w:WrapTextWithPunct /> <w:UseAsianBreakRules /> <w:DontGrowAutofit /> </w:Compatibility> <w:BrowserLevel>MicrosoftInternetExplorer4</w:BrowserLevel> </w:WordDocument> </xml><![endif]--><!--[if gte mso 9]><xml> <w:LatentStyles DefLockedState="false" LatentStyleCount="156"> </w:LatentStyles> </xml><![endif]--><!--[if gte mso 10]> <mce:style><!   /* Style Definitions */  table.MsoNormalTable 	{mso-style-name:"Tabla normal"; 	mso-tstyle-rowband-size:0; 	mso-tstyle-colband-size:0; 	mso-style-noshow:yes; 	mso-style-parent:""; 	mso-padding-alt:0cm 5.4pt 0cm 5.4pt; 	mso-para-margin:0cm; 	mso-para-margin-bottom:.0001pt; 	mso-pagination:widow-orphan; 	font-size:10.0pt; 	font-family:"Times New Roman"; 	mso-ansi-language:#0400; 	mso-fareast-language:#0400; 	mso-bidi-language:#0400;} --> <!--[endif] --></p>\r\n<p class="MsoNormal" style="text-align: justify;"><span style="font-family: Arial;" lang="ES"> </span></p>\r\n<ul>\r\n<li><span style="font-family: Arial;" lang="ES"><span>-<span style="font: 7pt &quot;Times New Roman&quot;;"> </span></span></span><span style="font-family: Arial;" lang="ES">Garantizar el funcionamiento eficiente de la informática como soporte técnico y de aseguramiento de la actividad fundamental del Sistema de la ONE.</span></li>\r\n</ul>', 0, 's5_fs_8', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, ''),
(89, 'Información General', '<h1><a href="index.php?option=com_content&amp;view=article&amp;id=42&amp;Itemid=6" style="background: url(images/group.jpg) no-repeat scroll left center transparent; padding-left: 26px;">Información General</a></h1>\r\n<p>El Sistema de Gestión de la Calidad tiene como objetivo organizar y     normalizar el trabajo actual de la entidad. Su implantación se basa en     la implementación de la Norma ISO 9001-2008, elaborada por la  Organización    Internacional de Estandarización (ISO). La misma es  adoptada (no adaptada)    por Cuba, convirtiéndose para nuestro país en  la Norma Cubana    NC-ISO 9001-2008.<img src="images/stories/iso_01_big.png" border="0" width="191" height="141" /></p>', 0, 's5_fs_1', 0, '0000-00-00 00:00:00', 1, 'mod_custom', 0, 0, 1, 'moduleclass_sfx=\n\n', 0, 0, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_modules_menu`
--

CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(16, 1),
(16, 42),
(17, 0),
(18, 1),
(18, 2),
(18, 3),
(18, 5),
(18, 7),
(18, 17),
(18, 23),
(18, 25),
(18, 26),
(18, 27),
(18, 28),
(18, 42),
(18, 43),
(18, 44),
(18, 45),
(18, 48),
(19, 1),
(19, 2),
(19, 3),
(19, 5),
(19, 7),
(19, 8),
(19, 14),
(19, 15),
(19, 16),
(19, 17),
(19, 21),
(19, 23),
(19, 25),
(19, 26),
(19, 27),
(19, 28),
(19, 29),
(19, 30),
(19, 31),
(19, 32),
(19, 33),
(19, 34),
(19, 35),
(19, 36),
(19, 37),
(19, 38),
(19, 42),
(19, 43),
(19, 44),
(19, 45),
(19, 47),
(19, 48),
(19, 52),
(19, 53),
(19, 54),
(19, 55),
(19, 59),
(19, 65),
(19, 68),
(19, 70),
(19, 78),
(19, 79),
(19, 80),
(19, 83),
(19, 84),
(20, 1),
(20, 2),
(20, 3),
(20, 5),
(20, 7),
(20, 8),
(20, 17),
(20, 23),
(20, 25),
(20, 26),
(20, 27),
(20, 28),
(20, 29),
(20, 30),
(20, 31),
(20, 32),
(20, 33),
(20, 34),
(20, 35),
(20, 36),
(20, 37),
(20, 38),
(20, 42),
(20, 43),
(20, 44),
(20, 45),
(20, 47),
(20, 48),
(20, 52),
(20, 53),
(20, 54),
(20, 55),
(20, 56),
(20, 59),
(20, 65),
(20, 68),
(20, 70),
(20, 78),
(20, 79),
(20, 80),
(21, 1),
(21, 42),
(21, 52),
(22, 1),
(22, 2),
(22, 3),
(22, 5),
(22, 7),
(22, 8),
(22, 17),
(22, 23),
(22, 25),
(22, 26),
(22, 27),
(22, 28),
(22, 29),
(22, 30),
(22, 31),
(22, 32),
(22, 33),
(22, 34),
(22, 35),
(22, 36),
(22, 37),
(22, 38),
(22, 42),
(22, 43),
(22, 44),
(22, 45),
(22, 47),
(22, 48),
(22, 52),
(22, 53),
(22, 54),
(22, 55),
(22, 56),
(22, 59),
(22, 64),
(22, 65),
(22, 68),
(22, 70),
(22, 71),
(22, 72),
(22, 73),
(22, 74),
(22, 75),
(22, 76),
(22, 77),
(22, 78),
(22, 79),
(22, 80),
(24, 1),
(25, 1),
(25, 52),
(27, 1),
(27, 2),
(27, 3),
(27, 5),
(27, 7),
(27, 8),
(27, 14),
(27, 15),
(27, 17),
(27, 21),
(27, 23),
(27, 25),
(27, 26),
(27, 27),
(27, 28),
(27, 29),
(27, 30),
(27, 31),
(27, 32),
(27, 33),
(27, 34),
(27, 35),
(27, 36),
(27, 37),
(27, 38),
(27, 42),
(27, 43),
(27, 44),
(27, 45),
(27, 47),
(27, 48),
(27, 52),
(27, 53),
(27, 54),
(27, 55),
(27, 59),
(27, 64),
(27, 65),
(27, 68),
(27, 70),
(27, 73),
(27, 78),
(27, 79),
(27, 80),
(27, 81),
(27, 82),
(28, 8),
(29, 0),
(30, 0),
(31, 1),
(31, 2),
(31, 3),
(31, 5),
(31, 7),
(31, 8),
(31, 14),
(31, 15),
(31, 16),
(31, 17),
(31, 21),
(31, 23),
(31, 25),
(31, 26),
(31, 27),
(31, 28),
(31, 29),
(31, 30),
(31, 31),
(31, 32),
(31, 33),
(31, 34),
(31, 35),
(31, 36),
(31, 37),
(31, 38),
(31, 42),
(31, 43),
(31, 44),
(31, 45),
(31, 47),
(31, 48),
(31, 52),
(31, 53),
(31, 54),
(31, 55),
(31, 59),
(31, 64),
(31, 65),
(31, 68),
(31, 70),
(31, 73),
(31, 78),
(31, 79),
(31, 80),
(31, 81),
(31, 82),
(32, 1),
(33, 28),
(33, 47),
(33, 52),
(33, 78),
(33, 83),
(34, 49),
(34, 56),
(35, 49),
(35, 56),
(37, 49),
(38, 49),
(39, 49),
(40, 49),
(41, 49),
(42, 49),
(43, 49),
(43, 56),
(44, 49),
(44, 56),
(45, 49),
(45, 56),
(46, 49),
(46, 56),
(47, 1),
(47, 52),
(48, 49),
(48, 56),
(49, 1),
(49, 52),
(50, 49),
(52, 49),
(53, 49),
(54, 49),
(55, 49),
(55, 56),
(56, 1),
(56, 2),
(56, 3),
(56, 5),
(56, 7),
(56, 8),
(56, 14),
(56, 15),
(56, 17),
(56, 21),
(56, 23),
(56, 25),
(56, 26),
(56, 27),
(56, 28),
(56, 29),
(56, 30),
(56, 31),
(56, 32),
(56, 33),
(56, 34),
(56, 35),
(56, 36),
(56, 37),
(56, 38),
(56, 42),
(56, 43),
(56, 44),
(56, 45),
(56, 47),
(56, 48),
(56, 52),
(56, 53),
(56, 54),
(56, 55),
(56, 59),
(56, 65),
(56, 68),
(56, 70),
(56, 78),
(56, 79),
(56, 80),
(56, 83),
(56, 84),
(57, 2),
(57, 3),
(57, 5),
(57, 7),
(57, 8),
(57, 17),
(57, 23),
(57, 25),
(57, 26),
(57, 27),
(57, 28),
(57, 29),
(57, 30),
(57, 31),
(57, 32),
(57, 33),
(57, 34),
(57, 35),
(57, 36),
(57, 37),
(57, 38),
(57, 42),
(57, 43),
(57, 44),
(57, 45),
(57, 47),
(57, 48),
(57, 52),
(57, 53),
(57, 54),
(57, 55),
(57, 56),
(57, 59),
(57, 64),
(57, 65),
(57, 68),
(57, 70),
(57, 78),
(57, 79),
(57, 80),
(58, 0),
(59, 49),
(60, 1),
(60, 52),
(61, 49),
(61, 56),
(62, 49),
(62, 56),
(63, 1),
(63, 2),
(63, 3),
(63, 5),
(63, 7),
(63, 8),
(63, 14),
(63, 15),
(63, 16),
(63, 17),
(63, 21),
(63, 23),
(63, 25),
(63, 26),
(63, 27),
(63, 28),
(63, 29),
(63, 30),
(63, 31),
(63, 32),
(63, 33),
(63, 34),
(63, 35),
(63, 36),
(63, 37),
(63, 38),
(63, 42),
(63, 43),
(63, 44),
(63, 45),
(63, 47),
(63, 48),
(63, 52),
(63, 53),
(63, 54),
(63, 55),
(63, 59),
(63, 64),
(63, 65),
(63, 68),
(63, 70),
(63, 73),
(63, 78),
(63, 79),
(63, 80),
(63, 81),
(63, 82),
(63, 83),
(63, 84),
(64, 49),
(64, 56),
(65, 1),
(66, 1),
(67, 0),
(68, 1),
(69, 1),
(70, 1),
(71, 1),
(72, 1),
(72, 52),
(73, 0),
(74, 1),
(75, 1),
(76, 1),
(76, 52),
(77, 83),
(78, 1),
(78, 13),
(78, 14),
(78, 15),
(78, 16),
(78, 17),
(78, 18),
(78, 19),
(78, 20),
(78, 21),
(78, 42),
(78, 43),
(78, 44),
(78, 45),
(78, 46),
(78, 87),
(78, 88),
(78, 89),
(78, 90),
(78, 91),
(78, 92),
(78, 93),
(78, 94),
(78, 95),
(78, 96),
(78, 97),
(78, 98),
(78, 99),
(78, 100),
(78, 101),
(78, 102),
(78, 103),
(78, 104),
(78, 105),
(78, 106),
(79, 1),
(79, 13),
(79, 14),
(79, 15),
(79, 17),
(79, 18),
(79, 19),
(79, 20),
(79, 21),
(79, 42),
(79, 43),
(79, 44),
(79, 45),
(79, 46),
(79, 87),
(79, 88),
(79, 89),
(79, 90),
(79, 91),
(79, 92),
(79, 93),
(79, 94),
(79, 95),
(79, 96),
(79, 97),
(79, 98),
(79, 99),
(79, 100),
(79, 101),
(79, 102),
(79, 103),
(79, 104),
(79, 105),
(79, 106),
(80, 1),
(81, 0),
(82, 0),
(83, 0),
(84, 0),
(85, 0),
(86, 0),
(87, 0),
(88, 0),
(89, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_newsfeeds`
--

CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL DEFAULT '0',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL DEFAULT '',
  `link` text NOT NULL,
  `filename` varchar(200) DEFAULT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `numarticles` int(11) unsigned NOT NULL DEFAULT '1',
  `cache_time` int(11) unsigned NOT NULL DEFAULT '3600',
  `checked_out` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `rtl` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `jos_newsfeeds`
--

INSERT INTO `jos_newsfeeds` (`catid`, `id`, `name`, `alias`, `link`, `filename`, `published`, `numarticles`, `cache_time`, `checked_out`, `checked_out_time`, `ordering`, `rtl`) VALUES
(4, 1, 'Joomla! - Official News', 'joomla-official-news', 'http://www.joomla.org/index.php?option=com_rss_xtd&feed=RSS2.0&type=com_frontpage&Itemid=1', '', 1, 5, 3600, 0, '0000-00-00 00:00:00', 8, 0),
(4, 2, 'Joomla! - Community News', 'joomla-community-news', 'http://www.joomla.org/index.php?option=com_rss_xtd&feed=RSS2.0&type=com_content&task=blogcategory&id=0&Itemid=33', '', 1, 5, 3600, 0, '0000-00-00 00:00:00', 9, 0),
(10, 4, 'Linux Today', 'linux-today', 'http://linuxtoday.com/backend/my-netscape.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 1, 0),
(5, 5, 'Business News', 'business-news', 'http://headlines.internet.com/internetnews/bus-news/news.rss', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 2, 0),
(11, 6, 'Web Developer News', 'web-developer-news', 'http://headlines.internet.com/internetnews/wd-news/news.rss', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 3, 0),
(10, 7, 'Linux Central:New Products', 'linux-centralnew-products', 'http://linuxcentral.com/backend/lcnew.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 4, 0),
(10, 8, 'Linux Central:Best Selling', 'linux-centralbest-selling', 'http://linuxcentral.com/backend/lcbestns.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 5, 0),
(10, 9, 'Linux Central:Daily Specials', 'linux-centraldaily-specials', 'http://linuxcentral.com/backend/lcspecialns.rdf', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 6, 0),
(9, 10, 'Internet:Finance News', 'internetfinance-news', 'http://headlines.internet.com/internetnews/fina-news/news.rss', '', 1, 3, 3600, 0, '0000-00-00 00:00:00', 7, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_plugins`
--

CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `element` varchar(100) NOT NULL DEFAULT '',
  `folder` varchar(100) NOT NULL DEFAULT '',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(3) NOT NULL DEFAULT '0',
  `iscore` tinyint(3) NOT NULL DEFAULT '0',
  `client_id` tinyint(3) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Volcar la base de datos para la tabla `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE 2.0', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'theme=advanced\ncleanup=1\ncleanup_startup=0\nautosave=0\ncompressed=0\nrelative_urls=1\ntext_direction=ltr\nlang_mode=0\nlang_code=en\ninvalid_elements=applet\ncontent_css=1\ncontent_css_custom=\nnewlines=0\ntoolbar=top\nhr=1\nsmilies=1\ntable=1\nstyle=1\nlayer=1\nxhtmlxtras=0\ntemplate=0\ndirectionality=1\nfullscreen=1\nhtml_height=550\nhtml_width=750\npreview=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'System - Mootools Upgrade', 'mtupgrade', 'system', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_polls`
--

CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `voters` int(9) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `access` int(11) NOT NULL DEFAULT '0',
  `lag` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Volcar la base de datos para la tabla `jos_polls`
--

INSERT INTO `jos_polls` (`id`, `title`, `alias`, `voters`, `checked_out`, `checked_out_time`, `published`, `access`, `lag`) VALUES
(14, 'I like the....', 'i-like-the', 347, 0, '0000-00-00 00:00:00', 1, 0, 86400);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_poll_data`
--

CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pollid` int(11) NOT NULL DEFAULT '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

--
-- Volcar la base de datos para la tabla `jos_poll_data`
--

INSERT INTO `jos_poll_data` (`id`, `pollid`, `text`, `hits`) VALUES
(1, 14, 'S5 Frontpage Slide', 97),
(2, 14, '3 S5 Box', 33),
(5, 14, 'Logout Template Feature', 42),
(6, 14, 'CB Registration module', 29),
(7, 14, '', 40),
(8, 14, '', 0),
(9, 14, '', 0),
(10, 14, '', 0),
(11, 14, '', 0),
(12, 14, '', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_poll_date`
--

CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL DEFAULT '0',
  `poll_id` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=347 ;

--
-- Volcar la base de datos para la tabla `jos_poll_date`
--

INSERT INTO `jos_poll_date` (`id`, `date`, `vote_id`, `poll_id`) VALUES
(1, '2007-12-13 15:11:00', 5, 14),
(2, '2007-12-14 15:54:00', 1, 14),
(3, '2007-12-16 08:06:00', 1, 14),
(4, '2007-12-16 13:16:00', 5, 14),
(5, '2007-12-16 16:05:00', 5, 14),
(6, '2007-12-17 18:48:00', 4, 14),
(7, '2007-12-18 11:49:00', 3, 14),
(8, '2007-12-18 23:09:00', 1, 14),
(9, '2007-12-20 04:57:00', 1, 14),
(10, '2007-12-20 12:34:00', 5, 14),
(11, '2007-12-21 09:44:00', 3, 14),
(12, '2007-12-21 12:15:00', 5, 14),
(13, '2007-12-23 23:45:00', 5, 14),
(14, '2007-12-24 07:22:00', 1, 14),
(15, '2007-12-24 07:22:00', 1, 14),
(16, '2007-12-24 09:15:00', 2, 14),
(17, '2007-12-25 23:31:00', 5, 14),
(18, '2007-12-26 11:11:00', 5, 14),
(19, '2007-12-26 15:16:00', 3, 14),
(20, '2007-12-26 23:30:00', 5, 14),
(21, '2007-12-27 07:55:00', 1, 14),
(22, '2007-12-27 16:07:00', 2, 14),
(23, '2007-12-28 13:57:00', 5, 14),
(24, '2007-12-29 07:15:00', 2, 14),
(25, '2007-12-29 15:44:00', 1, 14),
(26, '2007-12-29 23:12:00', 4, 14),
(27, '2007-12-30 07:26:00', 3, 14),
(28, '2008-01-02 04:12:00', 3, 14),
(29, '2008-01-02 08:10:00', 4, 14),
(30, '2008-01-03 04:58:00', 5, 14),
(31, '2008-01-03 10:04:00', 5, 14),
(32, '2008-01-04 08:24:00', 1, 14),
(33, '2008-01-04 15:46:00', 3, 14),
(34, '2008-01-05 21:43:00', 1, 14),
(35, '2008-01-06 09:27:00', 1, 14),
(36, '2008-01-07 04:24:00', 5, 14),
(37, '2008-01-07 04:53:00', 1, 14),
(38, '2008-01-07 14:22:00', 1, 14),
(39, '2008-01-08 00:41:00', 3, 14),
(40, '2008-01-09 10:44:00', 1, 14),
(41, '2008-01-09 19:49:00', 1, 14),
(42, '2008-01-10 23:51:00', 2, 14),
(43, '2008-01-14 06:03:00', 2, 14),
(44, '2008-01-16 03:16:00', 5, 14),
(45, '2008-01-16 06:03:00', 4, 14),
(46, '2008-01-18 17:03:00', 4, 14),
(47, '2008-01-19 10:39:00', 3, 14),
(48, '2008-01-20 10:28:00', 1, 14),
(49, '2008-01-22 14:08:00', 5, 14),
(50, '2008-01-22 20:09:00', 5, 14),
(51, '2008-01-24 02:00:00', 2, 14),
(52, '2008-01-24 04:54:00', 4, 14),
(53, '2008-01-25 19:30:00', 1, 14),
(54, '2008-01-31 19:58:00', 1, 14),
(55, '2008-02-03 01:01:00', 3, 14),
(56, '2008-02-15 18:19:00', 5, 14),
(57, '2008-02-16 00:28:00', 5, 14),
(58, '2008-02-16 02:07:00', 5, 14),
(59, '2008-02-16 05:42:00', 5, 14),
(60, '2008-02-16 09:30:00', 5, 14),
(61, '2008-02-16 10:31:00', 3, 14),
(62, '2008-02-16 14:07:00', 1, 14),
(63, '2008-02-17 09:13:00', 5, 14),
(64, '2008-02-17 13:40:00', 5, 14),
(65, '2008-02-17 19:13:00', 5, 14),
(66, '2008-02-18 11:05:00', 2, 14),
(67, '2008-02-18 11:05:00', 2, 14),
(68, '2008-02-18 21:50:00', 1, 14),
(69, '2008-02-19 12:35:00', 2, 14),
(70, '2008-02-19 23:30:00', 5, 14),
(71, '2008-02-19 23:35:00', 1, 14),
(72, '2008-02-20 10:36:00', 1, 14),
(73, '2008-02-21 05:09:00', 5, 14),
(74, '2008-02-21 09:25:00', 4, 14),
(75, '2008-02-22 05:19:00', 5, 14),
(76, '2008-02-24 04:48:00', 5, 14),
(77, '2008-02-24 10:19:00', 5, 14),
(78, '2008-02-24 12:58:00', 5, 14),
(79, '2008-02-25 06:41:00', 5, 14),
(80, '2008-02-25 07:52:00', 3, 14),
(81, '2008-02-27 16:13:00', 2, 14),
(82, '2008-02-28 10:44:00', 2, 14),
(83, '2008-02-28 15:28:00', 5, 14),
(84, '2008-03-01 07:11:00', 5, 14),
(85, '2008-03-03 09:12:00', 5, 14),
(86, '2008-03-03 15:59:00', 2, 14),
(87, '2008-03-03 16:02:00', 1, 14),
(88, '2008-03-03 22:07:00', 5, 14),
(89, '2008-03-06 00:43:00', 1, 14),
(90, '2008-03-06 11:09:00', 1, 14),
(91, '2008-03-06 13:34:00', 2, 14),
(92, '2008-03-07 05:50:00', 5, 14),
(93, '2008-03-07 09:03:00', 5, 14),
(94, '2008-03-07 10:04:00', 4, 14),
(95, '2008-03-07 13:26:00', 2, 14),
(96, '2008-03-07 14:33:00', 3, 14),
(97, '2008-03-08 06:55:00', 5, 14),
(98, '2008-03-09 15:32:00', 3, 14),
(99, '2008-03-09 20:25:00', 1, 14),
(100, '2008-03-10 09:56:00', 5, 14),
(101, '2008-03-10 10:36:00', 3, 14),
(102, '2008-03-10 13:56:00', 5, 14),
(103, '2008-03-10 14:26:00', 4, 14),
(104, '2008-03-11 06:45:00', 5, 14),
(105, '2008-03-11 10:28:00', 1, 14),
(106, '2008-03-15 06:22:00', 1, 14),
(107, '2008-03-15 09:02:00', 1, 14),
(108, '2008-03-15 16:32:00', 2, 14),
(109, '2008-03-15 17:04:00', 7, 14),
(110, '2008-03-16 09:32:00', 7, 14),
(111, '2008-03-16 13:33:00', 2, 14),
(112, '2008-03-16 16:24:00', 1, 14),
(113, '2008-03-16 16:53:00', 1, 14),
(114, '2008-03-16 17:16:00', 2, 14),
(115, '2008-03-16 21:40:00', 1, 14),
(116, '2008-03-17 01:16:00', 2, 14),
(117, '2008-03-17 03:22:00', 5, 14),
(118, '2008-03-17 05:16:00', 1, 14),
(119, '2008-03-17 07:37:00', 5, 14),
(120, '2008-03-17 08:05:00', 5, 14),
(121, '2008-03-17 09:50:00', 5, 14),
(122, '2008-03-17 14:06:00', 7, 14),
(123, '2008-03-17 16:43:00', 1, 14),
(124, '2008-03-17 20:00:00', 6, 14),
(125, '2008-03-17 20:54:00', 7, 14),
(126, '2008-03-18 08:22:00', 5, 14),
(127, '2008-03-18 15:04:00', 1, 14),
(128, '2008-03-18 15:05:00', 1, 14),
(129, '2008-03-18 17:57:00', 5, 14),
(130, '2008-03-18 19:16:00', 7, 14),
(131, '2008-03-18 20:36:00', 5, 14),
(132, '2008-03-19 01:46:00', 1, 14),
(133, '2008-03-19 02:23:00', 1, 14),
(134, '2008-03-19 09:47:00', 1, 14),
(135, '2008-03-19 11:12:00', 1, 14),
(136, '2008-03-19 14:59:00', 7, 14),
(137, '2008-03-19 15:28:00', 6, 14),
(138, '2008-03-19 18:21:00', 7, 14),
(139, '2008-03-19 23:23:00', 1, 14),
(140, '2008-03-20 07:06:00', 7, 14),
(141, '2008-03-20 07:22:00', 6, 14),
(142, '2008-03-20 09:25:00', 1, 14),
(143, '2008-03-21 06:56:00', 6, 14),
(144, '2008-03-21 08:06:00', 7, 14),
(145, '2008-03-21 08:18:00', 7, 14),
(146, '2008-03-21 14:18:00', 7, 14),
(147, '2008-03-21 17:29:00', 7, 14),
(148, '2008-03-22 07:42:00', 7, 14),
(149, '2008-03-22 08:23:00', 5, 14),
(150, '2008-03-22 11:02:00', 7, 14),
(151, '2008-03-22 12:45:00', 6, 14),
(152, '2008-03-22 16:32:00', 2, 14),
(153, '2008-03-22 18:21:00', 5, 14),
(154, '2008-03-23 02:08:00', 7, 14),
(155, '2008-03-23 11:50:00', 6, 14),
(156, '2008-03-23 17:43:00', 2, 14),
(157, '2008-03-23 20:39:00', 7, 14),
(158, '2008-03-23 22:45:00', 1, 14),
(159, '2008-03-24 00:18:00', 2, 14),
(160, '2008-03-24 01:23:00', 7, 14),
(161, '2008-03-24 20:08:00', 2, 14),
(162, '2008-03-24 22:07:00', 1, 14),
(163, '2008-03-24 23:36:00', 1, 14),
(164, '2008-03-25 00:36:00', 7, 14),
(165, '2008-03-25 07:14:00', 2, 14),
(166, '2008-03-25 16:52:00', 5, 14),
(167, '2008-03-25 21:53:00', 5, 14),
(168, '2008-03-26 05:03:00', 1, 14),
(169, '2008-03-26 06:13:00', 1, 14),
(170, '2008-03-26 11:40:00', 5, 14),
(171, '2008-03-26 11:46:00', 1, 14),
(172, '2008-03-26 16:13:00', 7, 14),
(173, '2008-03-26 16:40:00', 6, 14),
(174, '2008-03-27 02:12:00', 1, 14),
(175, '2008-03-27 04:05:00', 5, 14),
(176, '2008-03-27 05:16:00', 1, 14),
(177, '2008-03-27 17:24:00', 1, 14),
(178, '2008-03-28 04:14:00', 1, 14),
(179, '2008-03-28 10:01:00', 1, 14),
(180, '2008-03-28 11:14:00', 1, 14),
(181, '2008-03-28 12:58:00', 6, 14),
(182, '2008-03-28 18:56:00', 7, 14),
(183, '2008-03-29 05:52:00', 6, 14),
(184, '2008-03-29 07:33:00', 5, 14),
(185, '2008-03-29 21:23:00', 7, 14),
(186, '2008-03-30 05:20:00', 1, 14),
(187, '2008-03-30 07:55:00', 2, 14),
(188, '2008-03-30 09:40:00', 5, 14),
(189, '2008-03-30 15:26:00', 2, 14),
(190, '2008-03-30 18:26:00', 7, 14),
(191, '2008-03-30 19:26:00', 5, 14),
(192, '2008-03-30 21:45:00', 1, 14),
(193, '2008-03-31 04:08:00', 5, 14),
(194, '2008-03-31 11:13:00', 1, 14),
(195, '2008-03-31 14:11:00', 1, 14),
(196, '2008-03-31 20:15:00', 1, 14),
(197, '2008-04-01 00:45:00', 2, 14),
(198, '2008-04-01 05:32:00', 1, 14),
(199, '2008-04-01 05:35:00', 1, 14),
(200, '2008-04-01 05:58:00', 1, 14),
(201, '2008-04-01 06:37:00', 6, 14),
(202, '2008-04-01 09:46:00', 7, 14),
(203, '2008-04-01 10:34:00', 1, 14),
(204, '2008-04-01 13:05:00', 1, 14),
(205, '2008-04-01 14:35:00', 5, 14),
(206, '2008-04-01 16:04:00', 1, 14),
(207, '2008-04-03 02:15:00', 5, 14),
(208, '2008-04-03 08:06:00', 1, 14),
(209, '2008-04-04 02:30:00', 1, 14),
(210, '2008-04-04 04:05:00', 5, 14),
(211, '2008-04-04 18:56:00', 6, 14),
(212, '2008-04-04 20:46:00', 2, 14),
(213, '2008-04-04 22:21:00', 1, 14),
(214, '2008-04-05 00:59:00', 1, 14),
(215, '2008-04-05 04:15:00', 7, 14),
(216, '2008-04-05 10:30:00', 2, 14),
(217, '2008-04-05 12:26:00', 5, 14),
(218, '2008-04-05 16:53:00', 5, 14),
(219, '2008-04-06 01:04:00', 7, 14),
(220, '2008-04-06 09:12:00', 1, 14),
(221, '2008-04-06 19:16:00', 1, 14),
(222, '2008-04-06 22:02:00', 1, 14),
(223, '2008-04-07 07:13:00', 1, 14),
(224, '2008-04-07 09:52:00', 2, 14),
(225, '2008-04-07 17:10:00', 5, 14),
(226, '2008-04-07 18:41:00', 6, 14),
(227, '2008-04-07 20:56:00', 6, 14),
(228, '2008-04-08 01:22:00', 6, 14),
(229, '2008-04-08 02:11:00', 7, 14),
(230, '2008-04-08 02:12:00', 1, 14),
(231, '2008-04-08 03:42:00', 7, 14),
(232, '2008-04-08 10:06:00', 1, 14),
(233, '2008-04-08 12:00:00', 5, 14),
(234, '2008-04-08 14:19:00', 7, 14),
(235, '2008-04-08 15:53:00', 5, 14),
(236, '2008-04-08 21:46:00', 7, 14),
(237, '2008-04-09 14:26:00', 6, 14),
(238, '2008-04-09 19:19:00', 1, 14),
(239, '2008-04-10 02:25:00', 1, 14),
(240, '2008-04-10 11:51:00', 7, 14),
(241, '2008-04-11 03:27:00', 1, 14),
(242, '2008-04-11 17:35:00', 1, 14),
(243, '2008-04-12 09:41:00', 1, 14),
(244, '2008-04-12 13:26:00', 6, 14),
(245, '2008-04-12 22:41:00', 1, 14),
(246, '2008-04-13 09:44:00', 5, 14),
(247, '2008-04-13 10:07:00', 2, 14),
(248, '2008-04-13 14:56:00', 5, 14),
(249, '2008-04-13 15:53:00', 2, 14),
(250, '2008-04-14 00:18:00', 2, 14),
(251, '2008-04-14 10:45:00', 1, 14),
(252, '2008-04-14 12:11:00', 1, 14),
(253, '2008-04-14 16:55:00', 5, 14),
(254, '2008-04-14 19:02:00', 1, 14),
(255, '2008-04-15 07:30:00', 1, 14),
(256, '2008-04-15 14:18:00', 1, 14),
(257, '2008-04-15 20:12:00', 1, 14),
(258, '2008-04-15 21:23:00', 5, 14),
(259, '2008-04-16 02:14:00', 5, 14),
(260, '2008-04-16 14:26:00', 1, 14),
(261, '2008-04-18 05:02:00', 7, 14),
(262, '2008-04-18 07:23:00', 6, 14),
(263, '2008-04-18 16:52:00', 1, 14),
(264, '2008-04-19 08:37:00', 1, 14),
(265, '2008-04-21 04:02:00', 5, 14),
(266, '2008-04-21 05:34:00', 1, 14),
(267, '2008-04-23 12:29:00', 2, 14),
(268, '2008-04-26 04:26:00', 6, 14),
(269, '2008-04-26 21:16:00', 5, 14),
(270, '2008-04-29 09:33:00', 1, 14),
(271, '2008-04-29 09:45:00', 1, 14),
(272, '2008-04-29 20:30:00', 1, 14),
(273, '2008-04-30 01:19:00', 1, 14),
(274, '2008-04-30 09:02:00', 1, 14),
(275, '2008-04-30 16:39:00', 1, 14),
(276, '2008-04-30 20:17:00', 2, 14),
(277, '2008-05-01 05:20:00', 7, 14),
(278, '2008-05-01 15:44:00', 6, 14),
(279, '2008-05-02 05:44:00', 2, 14),
(280, '2008-05-02 13:17:00', 1, 14),
(281, '2008-05-02 14:06:00', 1, 14),
(282, '2008-05-02 21:43:00', 1, 14),
(283, '2008-05-03 04:34:00', 5, 14),
(284, '2008-05-04 00:48:00', 6, 14),
(285, '2008-05-04 12:04:00', 1, 14),
(286, '2008-05-04 13:03:00', 1, 14),
(287, '2008-05-04 14:32:00', 1, 14),
(288, '2008-05-05 12:58:00', 6, 14),
(289, '2008-05-06 17:27:00', 5, 14),
(290, '2008-05-06 18:03:00', 1, 14),
(291, '2008-05-07 00:03:00', 2, 14),
(292, '2008-05-07 11:23:00', 2, 14),
(293, '2008-05-08 09:53:00', 7, 14),
(294, '2008-05-08 11:11:00', 1, 14),
(295, '2008-05-08 15:40:00', 5, 14),
(296, '2008-05-08 17:04:00', 1, 14),
(297, '2008-05-10 04:30:00', 1, 14),
(298, '2008-05-10 06:29:00', 1, 14),
(299, '2008-05-11 10:21:00', 7, 14),
(300, '2008-05-11 21:06:00', 6, 14),
(301, '2008-05-11 21:52:00', 7, 14),
(302, '2008-05-12 18:18:00', 1, 14),
(303, '2008-05-18 00:52:00', 1, 14),
(304, '2008-05-18 08:39:00', 2, 14),
(305, '2008-05-19 11:57:00', 6, 14),
(306, '2008-05-20 04:09:00', 6, 14),
(307, '2008-05-22 17:01:00', 1, 14),
(308, '2008-05-23 03:02:00', 5, 14),
(309, '2008-05-23 08:04:00', 2, 14),
(310, '2008-05-24 04:10:00', 5, 14),
(311, '2008-05-24 06:14:00', 1, 14),
(312, '2008-05-25 18:40:00', 5, 14),
(313, '2008-05-28 10:03:00', 5, 14),
(314, '2008-05-28 15:52:00', 2, 14),
(315, '2008-05-29 10:04:00', 5, 14),
(316, '2008-05-29 14:23:00', 1, 14),
(317, '2008-05-30 08:12:00', 2, 14),
(318, '2008-05-30 10:36:00', 1, 14),
(319, '2008-05-30 13:07:00', 6, 14),
(320, '2008-05-30 16:56:00', 6, 14),
(321, '2008-05-31 13:06:00', 7, 14),
(322, '2008-06-05 16:10:00', 1, 14),
(323, '2008-06-10 06:03:00', 5, 14),
(324, '2008-06-11 17:11:00', 1, 14),
(325, '2008-06-11 17:14:00', 7, 14),
(326, '2008-06-11 21:00:00', 2, 14),
(327, '2008-06-12 11:51:00', 2, 14),
(328, '2008-06-13 12:34:00', 2, 14),
(329, '2008-06-14 07:27:00', 1, 14),
(330, '2008-06-15 07:02:00', 2, 14),
(331, '2008-06-17 05:10:00', 1, 14),
(332, '2008-06-17 15:13:00', 2, 14),
(333, '2008-06-17 18:21:00', 1, 14),
(334, '2008-06-19 11:29:00', 7, 14),
(335, '2008-06-20 08:05:00', 7, 14),
(336, '2008-06-20 11:21:00', 2, 14),
(337, '2008-06-21 12:17:00', 7, 14),
(338, '2008-06-23 00:16:00', 5, 14),
(339, '2008-06-23 13:27:00', 6, 14),
(340, '2008-06-25 04:16:00', 1, 14),
(341, '2008-06-25 13:37:00', 1, 14),
(342, '2008-06-26 16:24:00', 6, 14),
(343, '2008-06-27 19:01:00', 1, 14),
(344, '2008-06-28 08:52:00', 1, 14),
(345, '2008-07-07 02:32:00', 6, 14),
(346, '2008-07-07 13:33:00', 1, 14);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_poll_menu`
--

CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL DEFAULT '0',
  `menuid` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_poll_menu`
--

INSERT INTO `jos_poll_menu` (`pollid`, `menuid`) VALUES
(14, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_sections`
--

CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL DEFAULT '',
  `image_position` varchar(30) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) unsigned NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `access` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT '0',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'News', 'The News', 'news', 'articles.jpg', 'content', 'right', 'Select a news topic from the list below, then select a news article to read.', 1, 0, '0000-00-00 00:00:00', 1, 0, 1, ''),
(2, 'Newsflashes', 'Newsflashes', 'newsflashes', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 2, ''),
(3, 'FAQs', 'Frequently Asked Questions', 'faqs', 'pastarchives.jpg', 'content', 'left', 'From the list below choose one of our FAQs topics, then select an FAQ to read. If you have a question which is not in this section, please contact us.', 1, 0, '0000-00-00 00:00:00', 2, 0, 1, '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_session`
--

CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) DEFAULT '',
  `time` varchar(14) DEFAULT '',
  `session_id` varchar(200) NOT NULL DEFAULT '0',
  `guest` tinyint(4) DEFAULT '1',
  `userid` int(11) DEFAULT '0',
  `usertype` varchar(50) DEFAULT '',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `client_id` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('', '1330366707', 'cs4qpl6br6tutvgpdviuutdad0', 1, 0, '', 0, 0, '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1330366707;s:18:"session.timer.last";i:1330366707;s:17:"session.timer.now";i:1330366707;s:22:"session.client.browser";s:69:"Mozilla/5.0 (Windows NT 6.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:60:"/var/www/SRA/Calidad/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_stats_agents`
--

CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL DEFAULT '',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `hits` int(11) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_stats_agents`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_templates_menu`
--

CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` varchar(255) NOT NULL DEFAULT '',
  `menuid` int(11) NOT NULL DEFAULT '0',
  `client_id` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Volcar la base de datos para la tabla `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('commportal', 0, 0),
('joomla_admin', 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_users`
--

CREATE TABLE IF NOT EXISTS `jos_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(150) NOT NULL DEFAULT '',
  `email` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(100) NOT NULL DEFAULT '',
  `usertype` varchar(25) NOT NULL DEFAULT '',
  `block` tinyint(4) NOT NULL DEFAULT '0',
  `sendEmail` tinyint(4) DEFAULT '0',
  `gid` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `registerDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `lastvisitDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `activation` varchar(100) NOT NULL DEFAULT '',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usertype` (`usertype`),
  KEY `idx_name` (`name`),
  KEY `gid_block` (`gid`,`block`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=83 ;

--
-- Volcar la base de datos para la tabla `jos_users`
--

INSERT INTO `jos_users` (`id`, `name`, `username`, `email`, `password`, `usertype`, `block`, `sendEmail`, `gid`, `registerDate`, `lastvisitDate`, `activation`, `params`) VALUES
(62, 'Administrator', 'admin', 'admin@admin.com', 'c810fdde4c262c27d9a7eac9e115ca14:nujIWubxeuCUxmOP', 'Super Administrator', 0, 1, 25, '2007-12-01 14:06:50', '2012-01-19 20:56:40', '', 'editor=\nexpired=\nexpired_time='),
(81, 'Direcion', 'Direcion', 'bla@bla.es', '663608cb0c5c2b229de7f30e3c06ea1f:9vJl6PDZoxndKgSn5DdZRuegvZ6aCz1R', 'Administrator', 0, 0, 24, '2011-11-01 13:37:30', '0000-00-00 00:00:00', '', 'admin_language=\nlanguage=\neditor=tinymce\nhelpsite=\ntimezone=0\n\n'),
(82, 'Auditoria', 'Auditoria', 'Auditoria@otpr.co.cu', '6649b69b1cabf01c7fed2e56f92b1ad5:H5VTVYv4HcBpifAdbnrSQT0k9cz5A54k', 'Registered', 0, 0, 18, '2011-11-01 13:36:21', '0000-00-00 00:00:00', '', 'admin_language=\nlanguage=\neditor=\nhelpsite=\ntimezone=0\n\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jos_weblinks`
--

CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL DEFAULT '0',
  `sid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(250) NOT NULL DEFAULT '',
  `alias` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(250) NOT NULL DEFAULT '',
  `description` text NOT NULL,
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL DEFAULT '0',
  `published` tinyint(1) NOT NULL DEFAULT '0',
  `checked_out` int(11) NOT NULL DEFAULT '0',
  `checked_out_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL DEFAULT '0',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `approved` tinyint(1) NOT NULL DEFAULT '1',
  `params` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `jos_weblinks`
--

INSERT INTO `jos_weblinks` (`id`, `catid`, `sid`, `title`, `alias`, `url`, `description`, `date`, `hits`, `published`, `checked_out`, `checked_out_time`, `ordering`, `archived`, `approved`, `params`) VALUES
(1, 2, 0, 'Joomla!', 'joomla', 'http://www.joomla.org', 'Home of Joomla!', '2005-02-14 15:19:02', 87, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 'target=0'),
(2, 2, 0, 'php.net', 'phpnet', 'http://www.php.net', 'The language that Joomla! is developed in', '2004-07-07 11:33:24', 76, 1, 0, '0000-00-00 00:00:00', 3, 0, 1, ''),
(3, 2, 0, 'MySQL', 'mysql', 'http://www.mysql.com', 'The database that Joomla! uses', '2004-07-07 10:18:31', 75, 1, 0, '0000-00-00 00:00:00', 5, 0, 1, ''),
(4, 2, 0, 'OpenSourceMatters', 'opensourcematters', 'http://www.opensourcematters.org', 'Home of OSM', '2005-02-14 15:19:02', 80, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 'target=0'),
(5, 2, 0, 'Joomla! - Forums', 'joomla-forums', 'http://forum.joomla.org', 'Joomla! Forums', '2005-02-14 15:19:02', 83, 1, 0, '0000-00-00 00:00:00', 1, 0, 1, 'target=0');
